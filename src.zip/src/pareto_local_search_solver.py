from __future__ import annotations

import argparse
import csv
import io
import json
import time
from dataclasses import dataclass
from pathlib import Path

from constructive_solver import (
    Stop,
    build_routes,
    distance,
    make_stops,
    route_cost,
)


EPS = 1e-9


@dataclass
class SearchStats:
    passes: int = 0
    moves_accepted: int = 0
    two_opt_moves: int = 0
    relocate_moves: int = 0
    swap_moves: int = 0


def route_load(route: list[Stop]) -> float:
    return sum(stop.demand for stop in route if stop.kind != "depot")


def route_is_feasible(route: list[Stop], depot: Stop, capacity: float) -> bool:
    if route_load(route) > capacity + EPS:
        return False

    current = depot
    current_time = 0.0
    for stop in route:
        arrival = current_time + distance(current, stop)
        start = max(arrival, stop.ready_time)
        if start > stop.due_time + EPS:
            return False
        current_time = start + stop.service_time
        current = stop

    return current_time + distance(current, depot) <= depot.due_time + EPS


def compact_routes(routes: list[list[Stop]]) -> list[list[Stop]]:
    return [route for route in routes if route]


def solution_cost(routes: list[list[Stop]], depot: Stop) -> float:
    return sum(route_cost(route, depot) for route in routes)


def solution_is_feasible(
    routes: list[list[Stop]],
    depot: Stop,
    capacity: float,
    vehicle_count: int,
) -> bool:
    active_routes = compact_routes(routes)
    if len(active_routes) > vehicle_count:
        return False
    return all(route_is_feasible(route, depot, capacity) for route in active_routes)


def _replace_route(routes: list[list[Stop]], route_idx: int, new_route: list[Stop]) -> list[list[Stop]]:
    candidate = [list(route) for route in routes]
    candidate[route_idx] = new_route
    return compact_routes(candidate)


def try_two_opt(
    routes: list[list[Stop]],
    depot: Stop,
    capacity: float,
) -> tuple[list[list[Stop]], float] | None:
    for route_idx, route in enumerate(routes):
        if len(route) < 3:
            continue
        old_cost = route_cost(route, depot)
        for start in range(len(route) - 1):
            for end in range(start + 1, len(route)):
                new_route = route[:start] + list(reversed(route[start : end + 1])) + route[end + 1 :]
                if not route_is_feasible(new_route, depot, capacity):
                    continue
                new_cost = route_cost(new_route, depot)
                if new_cost < old_cost - EPS:
                    return _replace_route(routes, route_idx, new_route), old_cost - new_cost
    return None


def try_relocate(
    routes: list[list[Stop]],
    depot: Stop,
    capacity: float,
    vehicle_count: int,
) -> tuple[list[list[Stop]], float] | None:
    current_cost = solution_cost(routes, depot)
    for source_idx, source_route in enumerate(routes):
        for stop_idx, stop in enumerate(source_route):
            source_without = source_route[:stop_idx] + source_route[stop_idx + 1 :]
            for target_idx, target_route in enumerate(routes):
                for insert_idx in range(len(target_route) + 1):
                    candidate = [list(route) for route in routes]
                    if source_idx == target_idx:
                        adjusted_insert_idx = insert_idx
                        if insert_idx > stop_idx:
                            adjusted_insert_idx -= 1
                        if adjusted_insert_idx == stop_idx:
                            continue
                        new_route = source_without[:adjusted_insert_idx] + [stop] + source_without[adjusted_insert_idx:]
                        candidate[source_idx] = new_route
                    else:
                        new_target = target_route[:insert_idx] + [stop] + target_route[insert_idx:]
                        if not route_is_feasible(source_without, depot, capacity):
                            continue
                        if not route_is_feasible(new_target, depot, capacity):
                            continue
                        candidate[source_idx] = source_without
                        candidate[target_idx] = new_target

                    candidate = compact_routes(candidate)
                    if not solution_is_feasible(candidate, depot, capacity, vehicle_count):
                        continue
                    new_cost = solution_cost(candidate, depot)
                    if new_cost < current_cost - EPS:
                        return candidate, current_cost - new_cost
    return None


def try_swap(
    routes: list[list[Stop]],
    depot: Stop,
    capacity: float,
) -> tuple[list[list[Stop]], float] | None:
    for first_idx in range(len(routes)):
        for second_idx in range(first_idx + 1, len(routes)):
            first_route = routes[first_idx]
            second_route = routes[second_idx]
            old_cost = route_cost(first_route, depot) + route_cost(second_route, depot)
            for first_pos, first_stop in enumerate(first_route):
                for second_pos, second_stop in enumerate(second_route):
                    new_first = list(first_route)
                    new_second = list(second_route)
                    new_first[first_pos] = second_stop
                    new_second[second_pos] = first_stop
                    if not route_is_feasible(new_first, depot, capacity):
                        continue
                    if not route_is_feasible(new_second, depot, capacity):
                        continue
                    new_cost = route_cost(new_first, depot) + route_cost(new_second, depot)
                    if new_cost < old_cost - EPS:
                        candidate = [list(route) for route in routes]
                        candidate[first_idx] = new_first
                        candidate[second_idx] = new_second
                        return candidate, old_cost - new_cost
    return None


def local_search(
    routes: list[list[Stop]],
    depot: Stop,
    capacity: float,
    vehicle_count: int,
    max_passes: int,
) -> tuple[list[list[Stop]], SearchStats]:
    working = compact_routes([list(route) for route in routes])
    stats = SearchStats()
    if not solution_is_feasible(working, depot, capacity, vehicle_count):
        return working, stats

    for _ in range(max_passes):
        stats.passes += 1

        two_opt = try_two_opt(working, depot, capacity)
        if two_opt is not None:
            working, _ = two_opt
            stats.moves_accepted += 1
            stats.two_opt_moves += 1
            continue

        relocate = try_relocate(working, depot, capacity, vehicle_count)
        if relocate is not None:
            working, _ = relocate
            stats.moves_accepted += 1
            stats.relocate_moves += 1
            continue

        swap = try_swap(working, depot, capacity)
        if swap is not None:
            working, _ = swap
            stats.moves_accepted += 1
            stats.swap_moves += 1
            continue

        break

    return working, stats


def mark_nondominated(rows: list[dict]) -> list[dict]:
    feasible_rows = [row for row in rows if row["feasible"]]
    for row in rows:
        row["nondominated"] = False
        row["archive_point"] = False

    for row in feasible_rows:
        row_cost = float(row["transport_cost"])
        row_dissat = float(row["dissatisfaction"])
        dominated = False
        for other in feasible_rows:
            if other is row:
                continue
            other_cost = float(other["transport_cost"])
            other_dissat = float(other["dissatisfaction"])
            no_worse = other_cost <= row_cost + EPS and other_dissat <= row_dissat + EPS
            strictly_better = other_cost < row_cost - EPS or other_dissat < row_dissat - EPS
            if no_worse and strictly_better:
                dominated = True
                break
        row["nondominated"] = not dominated

    seen_objectives: set[tuple[float, float]] = set()
    for row in feasible_rows:
        if not row["nondominated"]:
            continue
        objective_key = (round(float(row["transport_cost"]), 6), round(float(row["dissatisfaction"]), 6))
        if objective_key in seen_objectives:
            continue
        seen_objectives.add(objective_key)
        row["archive_point"] = True
    return rows


def solve_rows(
    instance_path: str | Path,
    thresholds: list[float],
    max_passes: int,
) -> list[dict]:
    instance = json.loads(Path(instance_path).read_text(encoding="utf-8"))
    rows = []
    capacity = float(instance["vehicle_capacity"])
    vehicle_count = int(instance["vehicle_count"])

    for threshold in thresholds:
        started = time.perf_counter()
        depot, stops, audit = make_stops(instance, threshold)
        initial_routes, initial_feasible = build_routes(stops, depot, capacity, vehicle_count)
        initial_routes = compact_routes(initial_routes)
        initial_cost = solution_cost(initial_routes, depot)

        if initial_feasible:
            final_routes, stats = local_search(initial_routes, depot, capacity, vehicle_count, max_passes)
        else:
            final_routes = initial_routes
            stats = SearchStats()

        final_feasible = solution_is_feasible(final_routes, depot, capacity, vehicle_count)
        final_cost = solution_cost(final_routes, depot)
        elapsed = time.perf_counter() - started

        rows.append(
            {
                "instance": instance["name"],
                "source_file": instance["source"]["source_file"],
                "method": "constructive_plus_deterministic_local_search",
                "threshold": threshold,
                "transport_cost": round(final_cost, 6),
                "dissatisfaction": round(audit["dissatisfaction"], 6),
                "direct_count": audit["direct_count"],
                "indirect_count": audit["indirect_count"],
                "pickup_stop_count": audit["pickup_stop_count"],
                "routes_used": len(final_routes),
                "vehicle_count": vehicle_count,
                "feasible": final_feasible,
                "initial_transport_cost": round(initial_cost, 6),
                "initial_routes_used": len(initial_routes),
                "initial_feasible": initial_feasible,
                "cost_improvement": round(initial_cost - final_cost, 6),
                "local_search_passes": stats.passes,
                "moves_accepted": stats.moves_accepted,
                "two_opt_moves": stats.two_opt_moves,
                "relocate_moves": stats.relocate_moves,
                "swap_moves": stats.swap_moves,
                "elapsed_seconds": round(elapsed, 6),
                "nondominated": False,
                "archive_point": False,
            }
        )

    return mark_nondominated(rows)


def rows_to_csv(rows: list[dict]) -> str:
    if not rows:
        return ""
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=list(rows[0].keys()), lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    return output.getvalue()


def solve_instance(
    instance_path: str | Path,
    thresholds: list[float],
    max_passes: int,
    output_csv: str | Path,
) -> None:
    rows = solve_rows(instance_path, thresholds, max_passes)
    out_path = Path(output_csv)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(rows_to_csv(rows), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("instance", type=Path)
    parser.add_argument("--output-csv", type=Path)
    parser.add_argument("--thresholds", default="0,0.5,1,2,4,6,8,10")
    parser.add_argument("--max-passes", type=int, default=100)
    parser.add_argument("--stdout", action="store_true")
    args = parser.parse_args()

    thresholds = [float(value) for value in args.thresholds.split(",")]
    if args.stdout:
        print(rows_to_csv(solve_rows(args.instance, thresholds, args.max_passes)), end="")
        return
    if args.output_csv is None:
        raise SystemExit("--output-csv is required unless --stdout is used")
    solve_instance(args.instance, thresholds, args.max_passes, args.output_csv)
    print(args.output_csv)


if __name__ == "__main__":
    main()
