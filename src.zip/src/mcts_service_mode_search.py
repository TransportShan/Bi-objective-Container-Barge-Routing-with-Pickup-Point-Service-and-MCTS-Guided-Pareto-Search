from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
import random
import time
from dataclasses import dataclass, field
from pathlib import Path

from constructive_solver import Stop, build_routes, distance, route_cost
from pareto_local_search_solver import (
    SearchStats,
    compact_routes,
    local_search,
    mark_nondominated,
    solution_cost,
    solution_is_feasible,
)


EPS = 1e-9
ACTION_FULL_ENUM_CUTOFF = 8
METHOD_NAME = "mcts_guided_service_mode_local_search"


@dataclass(frozen=True)
class Member:
    customer_id: int
    pickup_id: int
    dissatisfaction: float
    saving_proxy: float


@dataclass(frozen=True)
class ServiceGroup:
    pickup_id: int
    members: tuple[Member, ...]
    action_levels: tuple[int, ...]


@dataclass
class Node:
    group_index: int
    actions: tuple[int, ...]
    untried: list[int]
    visits: int = 0
    value: float = 0.0
    children: dict[int, "Node"] = field(default_factory=dict)


def bool_value(value: object) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "y"}


def read_csv(path: Path) -> list[dict]:
    with path.open("r", newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def rows_to_csv(rows: list[dict], fieldnames: list[str]) -> str:
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=fieldnames, lineterminator="\n", extrasaction="ignore")
    writer.writeheader()
    for row in rows:
        writer.writerow({key: row.get(key, "") for key in fieldnames})
    return output.getvalue()


def objective_key(row: dict) -> tuple[float, float]:
    return (round(float(row["transport_cost"]), 6), round(float(row["dissatisfaction"]), 6))


def stable_hash(values: tuple[int, ...]) -> str:
    payload = ",".join(str(value) for value in values).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()[:16]


def depot_stop(instance: dict) -> Stop:
    depot = instance["depot"]
    return Stop(
        stop_id="depot",
        x=float(depot["x"]),
        y=float(depot["y"]),
        demand=0.0,
        ready_time=float(depot["ready_time"]),
        due_time=float(depot["due_time"]),
        service_time=float(depot["service_time"]),
        kind="depot",
        members=(),
    )


def direct_stop(customer: dict) -> Stop:
    customer_id = int(customer["node_id"])
    return Stop(
        stop_id=f"c{customer_id}",
        x=float(customer["x"]),
        y=float(customer["y"]),
        demand=float(customer["demand"]),
        ready_time=float(customer["ready_time"]),
        due_time=float(customer["due_time"]),
        service_time=float(customer["service_time"]),
        kind="direct_customer",
        members=(customer_id,),
    )


def pickup_stop(pickup: dict, member_rows: list[dict]) -> Stop:
    pickup_id = int(pickup["pickup_id"])
    members = tuple(sorted(int(row["node_id"]) for row in member_rows))
    return Stop(
        stop_id=f"p{pickup_id}",
        x=float(pickup["x"]),
        y=float(pickup["y"]),
        demand=sum(float(row["demand"]) for row in member_rows),
        ready_time=0.0,
        due_time=min(float(row["due_time"]) for row in member_rows),
        service_time=max(float(row["service_time"]) for row in member_rows),
        kind="pickup_point",
        members=members,
    )


def action_levels(size: int, full_enum_cutoff: int = ACTION_FULL_ENUM_CUTOFF) -> tuple[int, ...]:
    if size <= 0:
        return (0,)
    levels = {0, size}
    levels.add(max(0, round(0.25 * size)))
    levels.add(max(0, round(0.50 * size)))
    levels.add(max(0, round(0.75 * size)))
    if size <= full_enum_cutoff:
        levels.update(range(size + 1))
    return tuple(sorted(levels))


def build_service_groups(instance: dict) -> list[ServiceGroup]:
    depot = depot_stop(instance)
    customers = {int(row["node_id"]): row for row in instance["customers"]}
    pickup_by_id = {int(row["pickup_id"]): row for row in instance["pickup_points"]}
    grouped: dict[int, list[Member]] = {}

    for customer_id, customer in customers.items():
        nearest = instance["nearest_pickup"][str(customer_id)]
        if not bool_value(nearest["eligible"]):
            continue
        pickup_id = int(nearest["pickup_id"])
        pickup = pickup_by_id[pickup_id]
        c_stop = direct_stop(customer)
        p_stop = Stop(
            stop_id=f"proxy_p{pickup_id}",
            x=float(pickup["x"]),
            y=float(pickup["y"]),
            demand=0.0,
            ready_time=0.0,
            due_time=float(customer["due_time"]),
            service_time=float(customer["service_time"]),
            kind="pickup_proxy",
            members=(customer_id,),
        )
        direct_proxy = distance(depot, c_stop) + distance(c_stop, depot)
        pickup_proxy = distance(depot, p_stop) + distance(p_stop, depot)
        saving_proxy = direct_proxy - pickup_proxy
        grouped.setdefault(pickup_id, []).append(
            Member(
                customer_id=customer_id,
                pickup_id=pickup_id,
                dissatisfaction=float(nearest["dissatisfaction"]),
                saving_proxy=saving_proxy,
            )
        )

    groups: list[ServiceGroup] = []
    for pickup_id, members in grouped.items():
        ordered = tuple(
            sorted(
                members,
                key=lambda member: (
                    -(member.saving_proxy / (1.0 + member.dissatisfaction)),
                    member.dissatisfaction,
                    member.customer_id,
                ),
            )
        )
        groups.append(ServiceGroup(pickup_id=pickup_id, members=ordered, action_levels=action_levels(len(ordered))))

    return sorted(
        groups,
        key=lambda group: (
            -sum(member.saving_proxy for member in group.members),
            -len(group.members),
            group.pickup_id,
        ),
    )


def make_stops_from_actions(instance: dict, groups: list[ServiceGroup], actions: tuple[int, ...]) -> tuple[Stop, list[Stop], dict]:
    depot = depot_stop(instance)
    customers = {int(row["node_id"]): row for row in instance["customers"]}
    pickup_by_id = {int(row["pickup_id"]): row for row in instance["pickup_points"]}
    selected_by_pickup: dict[int, list[int]] = {}
    selected_ids: set[int] = set()
    total_dissatisfaction = 0.0

    for group, selected_count in zip(groups, actions):
        selected_count = min(max(0, selected_count), len(group.members))
        selected_members = group.members[:selected_count]
        if not selected_members:
            continue
        bucket = selected_by_pickup.setdefault(group.pickup_id, [])
        for member in selected_members:
            if member.customer_id in selected_ids:
                continue
            selected_ids.add(member.customer_id)
            bucket.append(member.customer_id)
            total_dissatisfaction += member.dissatisfaction

    stops: list[Stop] = []
    direct_count = 0
    for customer_id, customer in sorted(customers.items()):
        if customer_id in selected_ids:
            continue
        stops.append(direct_stop(customer))
        direct_count += 1

    pickup_stop_count = 0
    for pickup_id, members in sorted(selected_by_pickup.items()):
        if not members:
            continue
        member_rows = [customers[customer_id] for customer_id in sorted(members)]
        stops.append(pickup_stop(pickup_by_id[pickup_id], member_rows))
        pickup_stop_count += 1

    audit = {
        "direct_count": direct_count,
        "indirect_count": len(selected_ids),
        "pickup_stop_count": pickup_stop_count,
        "dissatisfaction": total_dissatisfaction,
    }
    return depot, stops, audit


def evaluate_actions(
    instance: dict,
    groups: list[ServiceGroup],
    actions: tuple[int, ...],
    max_passes: int,
    candidate_id: str,
    mcts_iteration: int | None,
    scalar_weight: float,
) -> dict:
    started = time.perf_counter()
    capacity = float(instance["vehicle_capacity"])
    vehicle_count = int(instance["vehicle_count"])
    depot, stops, audit = make_stops_from_actions(instance, groups, actions)
    initial_routes, initial_feasible = build_routes(stops, depot, capacity, vehicle_count)
    initial_routes = compact_routes(initial_routes)
    initial_cost = solution_cost(initial_routes, depot)

    if initial_feasible:
        final_routes, stats = local_search(initial_routes, depot, capacity, vehicle_count, max_passes)
    else:
        final_routes = initial_routes
        stats = SearchStats()

    final_feasible = solution_is_feasible(final_routes, depot, capacity, vehicle_count)
    final_cost = solution_cost(final_routes, depot)
    elapsed = time.perf_counter() - started
    return {
        "instance": instance["name"],
        "source_file": instance["source"]["source_file"],
        "method": METHOD_NAME,
        "source": "mcts_service_mode",
        "candidate_id": candidate_id,
        "threshold": "",
        "transport_cost": round(final_cost, 6),
        "dissatisfaction": round(audit["dissatisfaction"], 6),
        "direct_count": audit["direct_count"],
        "indirect_count": audit["indirect_count"],
        "pickup_stop_count": audit["pickup_stop_count"],
        "routes_used": len(final_routes),
        "vehicle_count": vehicle_count,
        "feasible": final_feasible,
        "initial_transport_cost": round(initial_cost, 6),
        "initial_routes_used": len(initial_routes),
        "initial_feasible": initial_feasible,
        "cost_improvement": round(initial_cost - final_cost, 6),
        "local_search_passes": stats.passes,
        "moves_accepted": stats.moves_accepted,
        "two_opt_moves": stats.two_opt_moves,
        "relocate_moves": stats.relocate_moves,
        "swap_moves": stats.swap_moves,
        "elapsed_seconds": round(elapsed, 6),
        "mcts_iteration": "" if mcts_iteration is None else mcts_iteration,
        "scalar_weight": round(scalar_weight, 6),
        "assignment_hash": stable_hash(actions),
        "groups_decided": len(actions),
        "nondominated": False,
        "archive_point": False,
    }


def normalize_seed_row(row: dict) -> dict:
    normalized = dict(row)
    normalized["source"] = "threshold_seed"
    normalized["candidate_id"] = f"threshold_{row.get('threshold', '')}"
    normalized["mcts_iteration"] = ""
    normalized["scalar_weight"] = ""
    normalized["assignment_hash"] = ""
    normalized["groups_decided"] = ""
    normalized["feasible"] = bool_value(row.get("feasible", False))
    normalized["initial_feasible"] = bool_value(row.get("initial_feasible", False))
    normalized["nondominated"] = False
    normalized["archive_point"] = False
    return normalized


def weighted_rollout_action(levels: tuple[int, ...], rng: random.Random, scalar_weight: float) -> int:
    if len(levels) == 1:
        return levels[0]
    weights: list[float] = []
    max_level = max(levels)
    for level in levels:
        share = 0.0 if max_level == 0 else level / max_level
        cost_bias = share
        service_bias = 1.0 - share
        exploratory = 0.20
        weights.append(exploratory + cost_bias + scalar_weight * service_bias)
    total = sum(weights)
    draw = rng.random() * total
    running = 0.0
    for level, weight in zip(levels, weights):
        running += weight
        if draw <= running:
            return level
    return levels[-1]


def choose_child(node: Node, exploration: float) -> Node:
    log_parent = math.log(max(node.visits, 1) + 1.0)

    def uct(child: Node) -> float:
        if child.visits == 0:
            return math.inf
        exploitation = child.value / child.visits
        exploration_term = exploration * math.sqrt(log_parent / child.visits)
        return exploitation + exploration_term

    return max(node.children.values(), key=uct)


def reward_from_row(row: dict, cost_scale: float, diss_scale: float, scalar_weight: float) -> float:
    if not bool_value(row["feasible"]):
        return -5.0
    cost_term = float(row["transport_cost"]) / max(cost_scale, EPS)
    diss_term = float(row["dissatisfaction"]) / max(diss_scale, EPS)
    return -(cost_term + scalar_weight * diss_term)


def baseline_scales(seed_rows: list[dict], groups: list[ServiceGroup]) -> tuple[float, float]:
    feasible_seed = [row for row in seed_rows if bool_value(row.get("feasible", False))]
    if feasible_seed:
        cost_scale = max(float(row["transport_cost"]) for row in feasible_seed)
    else:
        cost_scale = 1.0
    diss_scale = sum(member.dissatisfaction for group in groups for member in group.members)
    return max(cost_scale, 1.0), max(diss_scale, 1.0)


def run_search(
    instance_path: Path,
    seed_csv: Path,
    output_csv: Path,
    iterations: int,
    max_passes: int,
    exploration: float,
    seed: int,
    write_output: bool = True,
) -> tuple[dict, str]:
    started = time.perf_counter()
    rng = random.Random(seed)
    instance = json.loads(instance_path.read_text(encoding="utf-8"))
    groups = build_service_groups(instance)
    seed_rows = [normalize_seed_row(row) for row in read_csv(seed_csv)]
    cost_scale, diss_scale = baseline_scales(seed_rows, groups)

    root = Node(group_index=0, actions=(), untried=list(groups[0].action_levels if groups else ()))
    evaluated: dict[tuple[int, ...], dict] = {}
    generated_rows: list[dict] = []
    scalar_weights = [0.0, 0.15, 0.35, 0.70, 1.20, 2.00]

    for iteration in range(iterations):
        scalar_weight = scalar_weights[iteration % len(scalar_weights)]
        node = root
        path = [node]

        while node.group_index < len(groups) and not node.untried and node.children:
            node = choose_child(node, exploration)
            path.append(node)

        if node.group_index < len(groups) and node.untried:
            action = rng.choice(node.untried)
            node.untried.remove(action)
            child_actions = (*node.actions, action)
            next_index = node.group_index + 1
            child_untried = list(groups[next_index].action_levels) if next_index < len(groups) else []
            child = Node(group_index=next_index, actions=child_actions, untried=child_untried)
            node.children[action] = child
            node = child
            path.append(node)

        actions = list(node.actions)
        for group in groups[node.group_index :]:
            actions.append(weighted_rollout_action(group.action_levels, rng, scalar_weight))
        action_tuple = tuple(actions)

        row = evaluated.get(action_tuple)
        if row is None:
            row = evaluate_actions(
                instance=instance,
                groups=groups,
                actions=action_tuple,
                max_passes=max_passes,
                candidate_id=f"mcts_{iteration:04d}",
                mcts_iteration=iteration,
                scalar_weight=scalar_weight,
            )
            evaluated[action_tuple] = row
            generated_rows.append(row)

        reward = reward_from_row(row, cost_scale, diss_scale, scalar_weight)
        for visited in path:
            visited.visits += 1
            visited.value += reward

    combined_rows = [*seed_rows, *generated_rows]
    mark_nondominated(combined_rows)

    fieldnames = [
        "instance",
        "source_file",
        "method",
        "source",
        "candidate_id",
        "threshold",
        "transport_cost",
        "dissatisfaction",
        "direct_count",
        "indirect_count",
        "pickup_stop_count",
        "routes_used",
        "vehicle_count",
        "feasible",
        "initial_transport_cost",
        "initial_routes_used",
        "initial_feasible",
        "cost_improvement",
        "local_search_passes",
        "moves_accepted",
        "two_opt_moves",
        "relocate_moves",
        "swap_moves",
        "elapsed_seconds",
        "mcts_iteration",
        "scalar_weight",
        "assignment_hash",
        "groups_decided",
        "nondominated",
        "archive_point",
    ]
    csv_text = rows_to_csv(combined_rows, fieldnames)
    csv_sha256 = hashlib.sha256(csv_text.encode("utf-8")).hexdigest()
    if write_output:
        output_csv.parent.mkdir(parents=True, exist_ok=True)
        output_csv.write_text(csv_text, encoding="utf-8")

    elapsed = time.perf_counter() - started
    archive_rows = [row for row in combined_rows if bool_value(row.get("archive_point", False))]
    meta = {
        "instance": instance["name"],
        "instance_path": str(instance_path),
        "seed_csv": str(seed_csv),
        "output_csv": str(output_csv),
        "algorithm": METHOD_NAME,
        "iterations": iterations,
        "max_passes": max_passes,
        "exploration": exploration,
        "random_seed": seed,
        "service_groups": len(groups),
        "unique_mcts_evaluations": len(generated_rows),
        "threshold_seed_rows": len(seed_rows),
        "combined_rows": len(combined_rows),
        "archive_points": len(archive_rows),
        "wall_elapsed_seconds": round(elapsed, 6),
        "sha256": csv_sha256,
    }
    if write_output:
        output_csv.with_suffix(".meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    return meta, csv_text


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("instance", type=Path)
    parser.add_argument("--threshold-seed-csv", type=Path, required=True)
    parser.add_argument("--output-csv", type=Path, required=True)
    parser.add_argument("--iterations", type=int, default=120)
    parser.add_argument("--max-passes", type=int, default=100)
    parser.add_argument("--exploration", type=float, default=0.75)
    parser.add_argument("--seed", type=int, default=20260610)
    parser.add_argument("--emit-json", action="store_true")
    args = parser.parse_args()

    meta, csv_text = run_search(
        instance_path=args.instance,
        seed_csv=args.threshold_seed_csv,
        output_csv=args.output_csv,
        iterations=args.iterations,
        max_passes=args.max_passes,
        exploration=args.exploration,
        seed=args.seed,
        write_output=not args.emit_json,
    )
    if args.emit_json:
        print(json.dumps({"meta": meta, "csv": csv_text}))
    else:
        print(json.dumps(meta, indent=2))


if __name__ == "__main__":
    main()
