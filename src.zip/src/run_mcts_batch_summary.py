from __future__ import annotations

import argparse
import csv
import io
import json
import math
import sys
from pathlib import Path

from mcts_service_mode_search import bool_value, read_csv, run_search
from summarize_mcts_comparison import coverage, hypervolume


ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
THRESHOLD_DIR = RESULTS / "pareto_ls"
MCTS_DIR = RESULTS / "mcts_service_mode"


def read_csv_text(text: str) -> list[dict]:
    return list(csv.DictReader(io.StringIO(text)))


def objective(row: dict) -> tuple[float, float]:
    return (float(row["transport_cost"]), float(row["dissatisfaction"]))


def feasible_rows(rows: list[dict]) -> list[dict]:
    return [row for row in rows if bool_value(row.get("feasible", False))]


def archive_rows(rows: list[dict]) -> list[dict]:
    return [row for row in rows if bool_value(row.get("feasible", False)) and bool_value(row.get("archive_point", False))]


def output_csv(rows: list[dict]) -> str:
    if not rows:
        return ""
    out = io.StringIO()
    writer = csv.DictWriter(out, fieldnames=list(rows[0].keys()), lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    return out.getvalue()


def summarize_instance(threshold_path: Path, enhanced_rows: list[dict], meta: dict) -> dict:
    threshold_rows = read_csv(threshold_path)
    threshold_archive = archive_rows(threshold_rows)
    enhanced_archive = archive_rows(enhanced_rows)
    threshold_feasible = feasible_rows(threshold_rows)
    enhanced_feasible = feasible_rows(enhanced_rows)

    threshold_points = {tuple(round(value, 6) for value in objective(row)) for row in threshold_archive}
    enhanced_points = {tuple(round(value, 6) for value in objective(row)) for row in enhanced_archive}
    new_points = enhanced_points - threshold_points

    union_points = [objective(row) for row in [*threshold_archive, *enhanced_archive]]
    if union_points:
        max_cost = max(point[0] for point in union_points)
        max_dissat = max(point[1] for point in union_points)
        reference = (max_cost * 1.05 + 1.0, max_dissat * 1.05 + 1.0)
    else:
        reference = (1.0, 1.0)

    threshold_hv = hypervolume([objective(row) for row in threshold_archive], reference)
    enhanced_hv = hypervolume([objective(row) for row in enhanced_archive], reference)
    threshold_runtime = sum(float(row["elapsed_seconds"]) for row in threshold_rows)
    enhanced_runtime = threshold_runtime + float(meta["wall_elapsed_seconds"])
    best_threshold_cost = min((float(row["transport_cost"]) for row in threshold_feasible), default=math.nan)
    best_enhanced_cost = min((float(row["transport_cost"]) for row in enhanced_feasible), default=math.nan)
    cost_improvement_pct = (
        0.0
        if math.isnan(best_threshold_cost) or best_threshold_cost == 0.0
        else (best_threshold_cost - best_enhanced_cost) / best_threshold_cost * 100.0
    )

    return {
        "instance": enhanced_rows[0]["instance"] if enhanced_rows else threshold_path.stem,
        "threshold_archive_points": len(threshold_archive),
        "mcts_archive_points": len(enhanced_archive),
        "new_archive_points": len(new_points),
        "threshold_best_feasible_cost": f"{best_threshold_cost:.3f}",
        "mcts_best_feasible_cost": f"{best_enhanced_cost:.3f}",
        "best_cost_improvement_pct": f"{cost_improvement_pct:.2f}",
        "coverage_mcts_over_threshold": f"{coverage(enhanced_archive, threshold_archive):.3f}",
        "coverage_threshold_over_mcts": f"{coverage(threshold_archive, enhanced_archive):.3f}",
        "threshold_hypervolume": f"{threshold_hv:.3f}",
        "mcts_hypervolume": f"{enhanced_hv:.3f}",
        "hypervolume_gain_pct": f"{0.0 if threshold_hv == 0.0 else (enhanced_hv - threshold_hv) / threshold_hv * 100.0:.2f}",
        "threshold_runtime_seconds": f"{threshold_runtime:.3f}",
        "mcts_runtime_seconds": f"{enhanced_runtime:.3f}",
        "threshold_feasibility_rate": f"{len(threshold_feasible) / len(threshold_rows):.3f}" if threshold_rows else "",
        "mcts_feasibility_rate": f"{len(enhanced_feasible) / len(enhanced_rows):.3f}" if enhanced_rows else "",
        "mcts_unique_evaluations": meta["unique_mcts_evaluations"],
        "mcts_iterations": meta["iterations"],
        "mcts_seed": meta["random_seed"],
        "mcts_sha256": meta["sha256"],
    }


def run_batch(iterations: int, max_passes: int, seed: int, exploration: float) -> list[dict]:
    rows: list[dict] = []
    instance_paths = sorted(RESULTS.glob("single_*.json"))
    for instance_path in instance_paths:
        key = instance_path.stem
        threshold_path = THRESHOLD_DIR / f"{key}_pareto_ls.csv"
        if not threshold_path.exists():
            continue
        output_path = MCTS_DIR / f"{key}_mcts_enhanced.csv"
        meta, csv_text = run_search(
            instance_path=instance_path,
            seed_csv=threshold_path,
            output_csv=output_path,
            iterations=iterations,
            max_passes=max_passes,
            exploration=exploration,
            seed=seed,
            write_output=False,
        )
        enhanced_rows = read_csv_text(csv_text)
        rows.append(summarize_instance(threshold_path, enhanced_rows, meta))
        print(
            f"completed {meta['instance']}: archive={rows[-1]['mcts_archive_points']} "
            f"new={rows[-1]['new_archive_points']} runtime={rows[-1]['mcts_runtime_seconds']}",
            file=sys.stderr,
        )
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--iterations", type=int, default=120)
    parser.add_argument("--max-passes", type=int, default=100)
    parser.add_argument("--seed", type=int, default=20260610)
    parser.add_argument("--exploration", type=float, default=0.75)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    rows = run_batch(args.iterations, args.max_passes, args.seed, args.exploration)
    if args.json:
        print(json.dumps(rows, indent=2))
    else:
        print(output_csv(rows), end="")


if __name__ == "__main__":
    main()
