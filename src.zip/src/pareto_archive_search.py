from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
import random
import time
from dataclasses import dataclass
from pathlib import Path

from constructive_solver import Stop, build_routes, distance, route_cost, wait_arrival


@dataclass(frozen=True)
class EligibleCustomer:
    customer_id: int
    pickup_id: int
    dissatisfaction: float
    pickup_distance: float
    direct_proxy: float
    pickup_proxy: float
    saving_proxy: float


def xy_distance(a: dict, b: dict) -> float:
    return math.hypot(float(a["x"]) - float(b["x"]), float(a["y"]) - float(b["y"]))


def load_instance(instance_path: str | Path) -> dict:
    return json.loads(Path(instance_path).read_text(encoding="utf-8"))


def eligible_customers(instance: dict) -> list[EligibleCustomer]:
    depot = instance["depot"]
    customers = {int(row["node_id"]): row for row in instance["customers"]}
    pickups = {int(row["pickup_id"]): row for row in instance["pickup_points"]}
    rows: list[EligibleCustomer] = []

    for customer_id, customer in customers.items():
        nearest = instance["nearest_pickup"][str(customer_id)]
        if not nearest["eligible"]:
            continue
        pickup_id = int(nearest["pickup_id"])
        pickup = pickups[pickup_id]
        direct_proxy = 2.0 * xy_distance(depot, customer)
        pickup_proxy = 2.0 * xy_distance(depot, pickup)
        rows.append(
            EligibleCustomer(
                customer_id=customer_id,
                pickup_id=pickup_id,
                dissatisfaction=float(nearest["dissatisfaction"]),
                pickup_distance=float(nearest["distance"]),
                direct_proxy=direct_proxy,
                pickup_proxy=pickup_proxy,
                saving_proxy=direct_proxy - pickup_proxy,
            )
        )
    return sorted(rows, key=lambda row: row.customer_id)


def policy_token(indirect_customers: frozenset[int]) -> str:
    body = ",".join(str(customer_id) for customer_id in sorted(indirect_customers))
    return hashlib.sha256(body.encode("utf-8")).hexdigest()[:12]


def add_policy(
    policies: dict[frozenset[int], dict],
    family: str,
    rule: str,
    indirect_customers: set[int] | frozenset[int],
) -> None:
    frozen = frozenset(indirect_customers)
    if frozen in policies:
        policies[frozen]["aliases"].append(f"{family}:{rule}")
        return
    policies[frozen] = {
        "candidate_id": f"{family}_{policy_token(frozen)}",
        "family": family,
        "rule": rule,
        "aliases": [],
    }


def generate_policies(
    instance: dict,
    thresholds: list[float],
    random_samples: int,
    seed: int,
) -> dict[frozenset[int], dict]:
    eligible = eligible_customers(instance)
    policies: dict[frozenset[int], dict] = {}
    eligible_ids = {row.customer_id for row in eligible}

    add_policy(policies, "anchor", "all_direct", set())
    add_policy(policies, "anchor", "all_eligible_indirect", eligible_ids)

    for threshold in thresholds:
        indirect = {row.customer_id for row in eligible if row.dissatisfaction <= threshold + 1e-12}
        add_policy(policies, "threshold", f"diss_le_{threshold:g}", indirect)

    fractions = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
    low_diss = sorted(eligible, key=lambda row: (row.dissatisfaction, row.pickup_distance, row.customer_id))
    high_score = sorted(
        eligible,
        key=lambda row: (
            -(row.saving_proxy / (0.1 + row.dissatisfaction)),
            -row.saving_proxy,
            row.dissatisfaction,
            row.customer_id,
        ),
    )
    for fraction in fractions:
        k = max(1, round(len(eligible) * fraction)) if eligible else 0
        add_policy(
            policies,
            "rank_low_diss",
            f"top_{fraction:.1f}",
            {row.customer_id for row in low_diss[:k]},
        )
        add_policy(
            policies,
            "rank_saving",
            f"top_{fraction:.1f}",
            {row.customer_id for row in high_score[:k]},
        )

    by_pickup: dict[int, list[EligibleCustomer]] = {}
    for row in eligible:
        by_pickup.setdefault(row.pickup_id, []).append(row)
    pickup_groups = []
    for pickup_id, members in by_pickup.items():
        pickup_groups.append(
            {
                "pickup_id": pickup_id,
                "members": members,
                "sum_diss": sum(row.dissatisfaction for row in members),
                "sum_saving": sum(row.saving_proxy for row in members),
                "count": len(members),
            }
        )
    for penalty in [0.0, 0.1, 0.25, 0.5, 1.0, 2.0, 4.0]:
        ordered = sorted(
            pickup_groups,
            key=lambda group: (
                -(group["sum_saving"] - penalty * group["sum_diss"]),
                -group["count"],
                group["sum_diss"],
                group["pickup_id"],
            ),
        )
        for fraction in [0.25, 0.5, 0.75, 1.0]:
            k = max(1, round(len(ordered) * fraction)) if ordered else 0
            indirect = {
                row.customer_id
                for group in ordered[:k]
                for row in group["members"]
                if group["sum_saving"] - penalty * group["sum_diss"] >= -1e-9
            }
            add_policy(policies, "pickup_bundle", f"pen_{penalty:g}_top_{fraction:.2f}", indirect)

    rng = random.Random(seed)
    penalties = [0.0, 0.1, 0.25, 0.5, 1.0, 2.0, 4.0]
    if eligible:
        scores_by_penalty = {
            penalty: [row.saving_proxy - penalty * row.dissatisfaction for row in eligible]
            for penalty in penalties
        }
        for penalty in penalties:
            scores = scores_by_penalty[penalty]
            center = sorted(scores)[len(scores) // 2]
            spread = max(1.0, max(scores) - min(scores))
            for sample in range(random_samples):
                indirect = set()
                for row, score in zip(eligible, scores):
                    perturbed = score + rng.gauss(0.0, 0.12 * spread)
                    probability = 1.0 / (1.0 + math.exp(-(perturbed - center) / (0.15 * spread)))
                    if rng.random() < probability:
                        indirect.add(row.customer_id)
                add_policy(policies, "seeded_random", f"pen_{penalty:g}_sample_{sample:02d}", indirect)

    return policies


def make_stops_for_policy(instance: dict, indirect_customers: frozenset[int]) -> tuple[Stop, list[Stop], dict]:
    depot_data = instance["depot"]
    depot = Stop(
        stop_id="depot",
        x=float(depot_data["x"]),
        y=float(depot_data["y"]),
        demand=0.0,
        ready_time=float(depot_data["ready_time"]),
        due_time=float(depot_data["due_time"]),
        service_time=float(depot_data["service_time"]),
        kind="depot",
        members=(),
    )

    customers = {int(row["node_id"]): row for row in instance["customers"]}
    pickups = {int(row["pickup_id"]): row for row in instance["pickup_points"]}
    direct_stops: list[Stop] = []
    pickup_members: dict[int, list[int]] = {}
    total_dissatisfaction = 0.0
    indirect_count = 0

    for customer_id, customer in customers.items():
        nearest = instance["nearest_pickup"][str(customer_id)]
        use_indirect = (
            customer_id in indirect_customers
            and nearest["eligible"]
        )
        if use_indirect:
            pickup_id = int(nearest["pickup_id"])
            pickup_members.setdefault(pickup_id, []).append(customer_id)
            total_dissatisfaction += float(nearest["dissatisfaction"])
            indirect_count += 1
            continue
        direct_stops.append(
            Stop(
                stop_id=f"c{customer_id}",
                x=float(customer["x"]),
                y=float(customer["y"]),
                demand=float(customer["demand"]),
                ready_time=float(customer["ready_time"]),
                due_time=float(customer["due_time"]),
                service_time=float(customer["service_time"]),
                kind="direct_customer",
                members=(customer_id,),
            )
        )

    pickup_stops: list[Stop] = []
    for pickup_id, members in pickup_members.items():
        pickup = pickups[pickup_id]
        member_rows = [customers[member_id] for member_id in members]
        pickup_stops.append(
            Stop(
                stop_id=f"p{pickup_id}",
                x=float(pickup["x"]),
                y=float(pickup["y"]),
                demand=sum(float(row["demand"]) for row in member_rows),
                ready_time=0.0,
                due_time=min(float(row["due_time"]) for row in member_rows),
                service_time=max(float(row["service_time"]) for row in member_rows),
                kind="pickup_point",
                members=tuple(sorted(members)),
            )
        )

    audit = {
        "direct_count": len(direct_stops),
        "indirect_count": indirect_count,
        "pickup_stop_count": len(pickup_stops),
        "dissatisfaction": total_dissatisfaction,
    }
    return depot, [*direct_stops, *pickup_stops], audit


def route_is_feasible(route: list[Stop], depot: Stop, capacity: float) -> bool:
    if sum(stop.demand for stop in route if stop.kind != "depot") > capacity + 1e-9:
        return False
    current = depot
    time_value = 0.0
    for stop in route:
        _, start = wait_arrival(time_value, current, stop)
        if start > stop.due_time + 1e-9:
            return False
        time_value = start + stop.service_time
        current = stop
    return time_value + distance(current, depot) <= depot.due_time + 1e-9


def improve_route_2opt(route: list[Stop], depot: Stop, capacity: float, max_passes: int = 3) -> list[Stop]:
    if len(route) < 4:
        return route
    best = list(route)
    best_cost = route_cost(best, depot)
    for _ in range(max_passes):
        improved = False
        for i in range(len(best) - 1):
            for j in range(i + 2, len(best) + 1):
                candidate = best[:i] + list(reversed(best[i:j])) + best[j:]
                if not route_is_feasible(candidate, depot, capacity):
                    continue
                candidate_cost = route_cost(candidate, depot)
                if candidate_cost + 1e-9 < best_cost:
                    best = candidate
                    best_cost = candidate_cost
                    improved = True
                    break
            if improved:
                break
        if not improved:
            break
    return best


def evaluate_policy(instance: dict, policy_meta: dict, indirect_customers: frozenset[int]) -> dict:
    started = time.perf_counter()
    depot, stops, audit = make_stops_for_policy(instance, indirect_customers)
    routes, feasible = build_routes(
        stops,
        depot,
        capacity=float(instance["vehicle_capacity"]),
        vehicle_count=int(instance["vehicle_count"]),
    )
    capacity = float(instance["vehicle_capacity"])
    improved_routes = [improve_route_2opt(route, depot, capacity) for route in routes]
    cost = sum(route_cost(route, depot) for route in improved_routes)
    elapsed_ms = (time.perf_counter() - started) * 1000.0
    return {
        "instance": instance["name"],
        "source_file": instance["source"]["source_file"],
        "candidate_id": policy_meta["candidate_id"],
        "family": policy_meta["family"],
        "rule": policy_meta["rule"],
        "aliases": ";".join(policy_meta["aliases"]),
        "transport_cost": round(cost, 6),
        "dissatisfaction": round(audit["dissatisfaction"], 6),
        "direct_count": audit["direct_count"],
        "indirect_count": audit["indirect_count"],
        "pickup_stop_count": audit["pickup_stop_count"],
        "routes_used": len(improved_routes),
        "vehicle_count": int(instance["vehicle_count"]),
        "feasible": feasible and len(improved_routes) <= int(instance["vehicle_count"]),
        "elapsed_ms": round(elapsed_ms, 3),
    }


def nondominated_rows(rows: list[dict]) -> list[dict]:
    feasible = [row for row in rows if str(row["feasible"]).lower() == "true" or row["feasible"] is True]
    nondominated: list[dict] = []
    for row in feasible:
        dominated = False
        for other in feasible:
            if other is row:
                continue
            cost_le = float(other["transport_cost"]) <= float(row["transport_cost"]) + 1e-9
            diss_le = float(other["dissatisfaction"]) <= float(row["dissatisfaction"]) + 1e-9
            strictly = (
                float(other["transport_cost"]) < float(row["transport_cost"]) - 1e-9
                or float(other["dissatisfaction"]) < float(row["dissatisfaction"]) - 1e-9
            )
            if cost_le and diss_le and strictly:
                dominated = True
                break
        if not dominated:
            nondominated.append(row)
    unique: dict[tuple[float, float], dict] = {}
    for row in sorted(
        nondominated,
        key=lambda item: (
            float(item["dissatisfaction"]),
            float(item["transport_cost"]),
            item["family"] != "anchor",
            str(item["candidate_id"]),
        ),
    ):
        key = (round(float(row["transport_cost"]), 6), round(float(row["dissatisfaction"]), 6))
        unique.setdefault(key, row)
    return list(unique.values())


def rows_to_csv(rows: list[dict]) -> str:
    if not rows:
        return ""
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=list(rows[0].keys()), lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    return output.getvalue()


def run_search(
    instance_path: str | Path,
    thresholds: list[float],
    random_samples: int,
    seed: int,
) -> tuple[list[dict], list[dict]]:
    instance = load_instance(instance_path)
    policies = generate_policies(instance, thresholds, random_samples, seed)
    rows = [
        evaluate_policy(instance, meta, indirect_customers)
        for indirect_customers, meta in sorted(
            policies.items(),
            key=lambda item: (item[1]["family"], item[1]["rule"], item[1]["candidate_id"]),
        )
    ]
    return rows, nondominated_rows(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("instance", type=Path)
    parser.add_argument("--output-candidates", type=Path)
    parser.add_argument("--output-pareto", type=Path)
    parser.add_argument("--thresholds", default="0,0.25,0.5,0.75,1,1.5,2,3,4,6,8,10")
    parser.add_argument("--random-samples", type=int, default=6)
    parser.add_argument("--seed", type=int, default=20260610)
    parser.add_argument("--stdout", choices=["candidates", "pareto"])
    args = parser.parse_args()

    thresholds = [float(value) for value in args.thresholds.split(",") if value.strip()]
    candidates, pareto = run_search(args.instance, thresholds, args.random_samples, args.seed)
    if args.stdout == "candidates":
        print(rows_to_csv(candidates), end="")
        return
    if args.stdout == "pareto":
        print(rows_to_csv(pareto), end="")
        return
    if args.output_candidates is None or args.output_pareto is None:
        raise SystemExit("--output-candidates and --output-pareto are required unless --stdout is used")
    args.output_candidates.parent.mkdir(parents=True, exist_ok=True)
    args.output_pareto.parent.mkdir(parents=True, exist_ok=True)
    args.output_candidates.write_text(rows_to_csv(candidates), encoding="utf-8")
    args.output_pareto.write_text(rows_to_csv(pareto), encoding="utf-8")
    print(args.output_pareto)


if __name__ == "__main__":
    main()
