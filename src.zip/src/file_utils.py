from __future__ import annotations

from pathlib import Path
import subprocess
import time


def atomic_write_text(path: str | Path, text: str, encoding: str = "utf-8") -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    if not target.exists():
        target.touch()
    last_error: PermissionError | None = None
    for attempt in range(10):
        try:
            with target.open("w", encoding=encoding, newline="") as handle:
                handle.write(text)
            return
        except PermissionError as exc:
            last_error = exc
            time.sleep(0.2 * (attempt + 1))
    quoted = str(target).replace("'", "''")
    command = f"Set-Content -Path '{quoted}' -Value $input -Encoding UTF8"
    completed = subprocess.run(
        ["powershell.exe", "-NoProfile", "-Command", command],
        input=text,
        text=True,
        capture_output=True,
    )
    if completed.returncode == 0:
        return
    if last_error is not None:
        raise PermissionError(
            f"{last_error}; PowerShell fallback failed with code {completed.returncode}; "
            f"stdout={completed.stdout!r}; stderr={completed.stderr!r}"
        )
    completed.check_returncode()
