from __future__ import annotations

import argparse
import csv
import io
import json
import math
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Stop:
    stop_id: str
    x: float
    y: float
    demand: float
    ready_time: float
    due_time: float
    service_time: float
    kind: str
    members: tuple[int, ...]


def distance(a: Stop, b: Stop) -> float:
    return math.hypot(a.x - b.x, a.y - b.y)


def wait_arrival(current_time: float, from_stop: Stop, to_stop: Stop) -> tuple[float, float]:
    arrival = current_time + distance(from_stop, to_stop)
    start = max(arrival, to_stop.ready_time)
    return arrival, start


def is_feasible_next(route: list[Stop], candidate: Stop, depot: Stop, capacity: float) -> bool:
    load = sum(stop.demand for stop in route if stop.kind != "depot") + candidate.demand
    if load > capacity + 1e-9:
        return False

    current = depot
    time = 0.0
    for stop in [*route, candidate]:
        _, start = wait_arrival(time, current, stop)
        if start > stop.due_time + 1e-9:
            return False
        time = start + stop.service_time
        current = stop

    back_arrival = time + distance(current, depot)
    return back_arrival <= depot.due_time + 1e-9


def route_cost(route: list[Stop], depot: Stop) -> float:
    if not route:
        return 0.0
    total = distance(depot, route[0])
    total += sum(distance(a, b) for a, b in zip(route, route[1:]))
    total += distance(route[-1], depot)
    return total


def build_routes(stops: list[Stop], depot: Stop, capacity: float, vehicle_count: int) -> tuple[list[list[Stop]], bool]:
    remaining = sorted(stops, key=lambda s: (s.due_time, s.ready_time, s.stop_id))
    routes: list[list[Stop]] = []
    feasible = True

    while remaining:
        route: list[Stop] = []
        while True:
            feasible_candidates = [s for s in remaining if is_feasible_next(route, s, depot, capacity)]
            if not feasible_candidates:
                break
            current = route[-1] if route else depot
            chosen = min(
                feasible_candidates,
                key=lambda s: (
                    distance(current, s),
                    s.due_time,
                    s.stop_id,
                ),
            )
            route.append(chosen)
            remaining.remove(chosen)

        if not route:
            # Preserve the impossible stop in the output rather than hiding infeasibility.
            feasible = False
            route = [remaining.pop(0)]
        routes.append(route)

    if len(routes) > vehicle_count:
        feasible = False
    return routes, feasible


def make_stops(instance: dict, dissatisfaction_threshold: float) -> tuple[Stop, list[Stop], dict]:
    depot_data = instance["depot"]
    depot = Stop(
        stop_id="depot",
        x=float(depot_data["x"]),
        y=float(depot_data["y"]),
        demand=0.0,
        ready_time=float(depot_data["ready_time"]),
        due_time=float(depot_data["due_time"]),
        service_time=float(depot_data["service_time"]),
        kind="depot",
        members=(),
    )

    customers = {int(row["node_id"]): row for row in instance["customers"]}
    pickup_by_id = {int(row["pickup_id"]): row for row in instance["pickup_points"]}
    direct_stops: list[Stop] = []
    pickup_members: dict[int, list[int]] = {}
    total_dissatisfaction = 0.0
    indirect_count = 0

    for customer_id, customer in customers.items():
        nearest = instance["nearest_pickup"][str(customer_id)]
        if nearest["eligible"] and nearest["dissatisfaction"] <= dissatisfaction_threshold:
            pickup_id = int(nearest["pickup_id"])
            pickup_members.setdefault(pickup_id, []).append(customer_id)
            total_dissatisfaction += float(nearest["dissatisfaction"])
            indirect_count += 1
        else:
            direct_stops.append(
                Stop(
                    stop_id=f"c{customer_id}",
                    x=float(customer["x"]),
                    y=float(customer["y"]),
                    demand=float(customer["demand"]),
                    ready_time=float(customer["ready_time"]),
                    due_time=float(customer["due_time"]),
                    service_time=float(customer["service_time"]),
                    kind="direct_customer",
                    members=(customer_id,),
                )
            )

    pickup_stops: list[Stop] = []
    for pickup_id, members in pickup_members.items():
        pickup = pickup_by_id[pickup_id]
        member_rows = [customers[mid] for mid in members]
        pickup_stops.append(
            Stop(
                stop_id=f"p{pickup_id}",
                x=float(pickup["x"]),
                y=float(pickup["y"]),
                demand=sum(float(row["demand"]) for row in member_rows),
                ready_time=0.0,
                due_time=min(float(row["due_time"]) for row in member_rows),
                service_time=max(float(row["service_time"]) for row in member_rows),
                kind="pickup_point",
                members=tuple(sorted(members)),
            )
        )

    audit = {
        "direct_count": len(direct_stops),
        "indirect_count": indirect_count,
        "pickup_stop_count": len(pickup_stops),
        "dissatisfaction": total_dissatisfaction,
    }
    return depot, [*direct_stops, *pickup_stops], audit


def solve_rows(instance_path: str | Path, thresholds: list[float]) -> list[dict]:
    instance = json.loads(Path(instance_path).read_text(encoding="utf-8"))
    rows = []
    for threshold in thresholds:
        depot, stops, audit = make_stops(instance, threshold)
        routes, feasible = build_routes(
            stops,
            depot,
            capacity=float(instance["vehicle_capacity"]),
            vehicle_count=int(instance["vehicle_count"]),
        )
        cost = sum(route_cost(route, depot) for route in routes)
        rows.append(
            {
                "instance": instance["name"],
                "source_file": instance["source"]["source_file"],
                "threshold": threshold,
                "transport_cost": round(cost, 6),
                "dissatisfaction": round(audit["dissatisfaction"], 6),
                "direct_count": audit["direct_count"],
                "indirect_count": audit["indirect_count"],
                "pickup_stop_count": audit["pickup_stop_count"],
                "routes_used": len(routes),
                "vehicle_count": int(instance["vehicle_count"]),
                "feasible": feasible,
            }
        )
    return rows


def rows_to_csv(rows: list[dict]) -> str:
    if not rows:
        return ""
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=list(rows[0].keys()), lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    return output.getvalue()


def solve_instance(instance_path: str | Path, thresholds: list[float], output_csv: str | Path) -> None:
    rows = solve_rows(instance_path, thresholds)
    out_path = Path(output_csv)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out_path.open("w", newline="", encoding="utf-8") as handle:
        handle.write(rows_to_csv(rows))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("instance", type=Path)
    parser.add_argument("--output-csv", type=Path)
    parser.add_argument("--thresholds", default="0,0.5,1,2,4,6,8,10")
    parser.add_argument("--stdout", action="store_true")
    args = parser.parse_args()
    thresholds = [float(value) for value in args.thresholds.split(",")]
    if args.stdout:
        print(rows_to_csv(solve_rows(args.instance, thresholds)), end="")
        return
    if args.output_csv is None:
        raise SystemExit("--output-csv is required unless --stdout is used")
    solve_instance(args.instance, thresholds, args.output_csv)
    print(args.output_csv)


if __name__ == "__main__":
    main()
