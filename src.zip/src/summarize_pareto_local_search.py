from __future__ import annotations

import argparse
import csv
import hashlib
from pathlib import Path


def sha256(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def summarize_file(path: Path) -> dict:
    with path.open("r", newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))

    feasible_rows = [row for row in rows if row["feasible"].lower() == "true"]
    nondominated_rows = [row for row in feasible_rows if row["nondominated"].lower() == "true"]
    archive_rows = [row for row in feasible_rows if row["archive_point"].lower() == "true"]
    improved_rows = [row for row in rows if float(row["cost_improvement"]) > 1e-9]

    return {
        "result_file": str(path),
        "instance": rows[0]["instance"] if rows else path.stem,
        "rows": len(rows),
        "feasible_rows": len(feasible_rows),
        "nondominated_rows": len(nondominated_rows),
        "archive_points": len(archive_rows),
        "best_feasible_cost": min((float(row["transport_cost"]) for row in feasible_rows), default=""),
        "best_archive_cost": min((float(row["transport_cost"]) for row in archive_rows), default=""),
        "min_feasible_dissatisfaction": min((float(row["dissatisfaction"]) for row in feasible_rows), default=""),
        "max_indirect_feasible": max((int(row["indirect_count"]) for row in feasible_rows), default=""),
        "improved_rows": len(improved_rows),
        "max_cost_improvement": max((float(row["cost_improvement"]) for row in rows), default=0.0),
        "total_moves_accepted": sum(int(row["moves_accepted"]) for row in rows),
        "sha256": sha256(path),
    }


def rows_to_csv(rows: list[dict]) -> str:
    if not rows:
        return ""
    import io

    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=list(rows[0].keys()), lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    return output.getvalue()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-dir", type=Path, required=True)
    parser.add_argument("--pattern", default="*_pareto_ls.csv")
    parser.add_argument("--output-csv", type=Path, required=True)
    args = parser.parse_args()

    result_files = sorted(args.input_dir.glob(args.pattern))
    summary_rows = [summarize_file(path) for path in result_files]
    args.output_csv.parent.mkdir(parents=True, exist_ok=True)
    args.output_csv.write_text(rows_to_csv(summary_rows), encoding="utf-8")
    print(args.output_csv)


if __name__ == "__main__":
    main()
