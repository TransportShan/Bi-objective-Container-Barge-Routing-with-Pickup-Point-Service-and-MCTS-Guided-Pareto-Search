from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
from pathlib import Path


EPS = 1e-9


def bool_value(value: object) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "y"}


def read_csv(path: Path) -> list[dict]:
    with path.open("r", newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=list(rows[0].keys()), lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    path.write_text(output.getvalue(), encoding="utf-8")


def rows_to_csv(rows: list[dict]) -> str:
    if not rows:
        return ""
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=list(rows[0].keys()), lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    return output.getvalue()


def to_float(row: dict, key: str, default: float = 0.0) -> float:
    value = row.get(key, "")
    if value == "":
        return default
    return float(value)


def objective(row: dict) -> tuple[float, float]:
    return (to_float(row, "transport_cost"), to_float(row, "dissatisfaction"))


def dominates(first: tuple[float, float], second: tuple[float, float]) -> bool:
    return first[0] <= second[0] + EPS and first[1] <= second[1] + EPS


def strict_dominates(first: tuple[float, float], second: tuple[float, float]) -> bool:
    return dominates(first, second) and (first[0] < second[0] - EPS or first[1] < second[1] - EPS)


def archive_rows(rows: list[dict]) -> list[dict]:
    return [row for row in rows if bool_value(row.get("feasible", False)) and bool_value(row.get("archive_point", False))]


def feasible_rows(rows: list[dict]) -> list[dict]:
    return [row for row in rows if bool_value(row.get("feasible", False))]


def coverage(covering_archive: list[dict], covered_archive: list[dict]) -> float:
    if not covered_archive:
        return math.nan
    covering_points = [objective(row) for row in covering_archive]
    covered_points = [objective(row) for row in covered_archive]
    count = 0
    for point in covered_points:
        if any(dominates(candidate, point) for candidate in covering_points):
            count += 1
    return count / len(covered_points)


def hypervolume(points: list[tuple[float, float]], reference: tuple[float, float]) -> float:
    if not points:
        return 0.0
    nondominated = []
    for point in points:
        if any(strict_dominates(other, point) for other in points if other is not point):
            continue
        nondominated.append(point)
    nondominated = sorted(set((round(c, 6), round(d, 6)) for c, d in nondominated), key=lambda p: p[0])
    area = 0.0
    best_dissat = reference[1]
    for cost, dissat in nondominated:
        if dissat >= best_dissat - EPS:
            continue
        width = max(reference[0] - cost, 0.0)
        height = max(best_dissat - dissat, 0.0)
        area += width * height
        best_dissat = dissat
    return area


def file_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def instance_key(path: Path, suffix: str) -> str:
    return path.name.removesuffix(suffix)


def summarize(threshold_dir: Path, mcts_dir: Path, output_csv: Path, write_output: bool = True) -> tuple[list[dict], str]:
    threshold_files = {instance_key(path, "_pareto_ls.csv"): path for path in threshold_dir.glob("*_pareto_ls.csv")}
    mcts_files = {instance_key(path, "_mcts_enhanced.csv"): path for path in mcts_dir.glob("*_mcts_enhanced.csv")}
    rows: list[dict] = []

    for key in sorted(set(threshold_files) & set(mcts_files)):
        threshold_path = threshold_files[key]
        mcts_path = mcts_files[key]
        threshold = read_csv(threshold_path)
        enhanced = read_csv(mcts_path)
        threshold_archive = archive_rows(threshold)
        enhanced_archive = archive_rows(enhanced)
        threshold_feasible = feasible_rows(threshold)
        enhanced_feasible = feasible_rows(enhanced)
        meta_path = mcts_path.with_suffix(".meta.json")
        meta = json.loads(meta_path.read_text(encoding="utf-8")) if meta_path.exists() else {}

        threshold_points = {tuple(round(value, 6) for value in objective(row)) for row in threshold_archive}
        enhanced_points = {tuple(round(value, 6) for value in objective(row)) for row in enhanced_archive}
        new_points = enhanced_points - threshold_points

        union_points = [objective(row) for row in [*threshold_archive, *enhanced_archive]]
        if union_points:
            max_cost = max(point[0] for point in union_points)
            max_dissat = max(point[1] for point in union_points)
            reference = (max_cost * 1.05 + 1.0, max_dissat * 1.05 + 1.0)
        else:
            reference = (1.0, 1.0)
        threshold_hv = hypervolume([objective(row) for row in threshold_archive], reference)
        enhanced_hv = hypervolume([objective(row) for row in enhanced_archive], reference)
        threshold_runtime = sum(to_float(row, "elapsed_seconds") for row in threshold)
        enhanced_runtime = threshold_runtime + float(meta.get("wall_elapsed_seconds", 0.0))

        best_threshold_cost = min((to_float(row, "transport_cost") for row in threshold_feasible), default=math.nan)
        best_enhanced_cost = min((to_float(row, "transport_cost") for row in enhanced_feasible), default=math.nan)
        cost_improvement_pct = (
            0.0
            if math.isnan(best_threshold_cost) or best_threshold_cost == 0.0
            else (best_threshold_cost - best_enhanced_cost) / best_threshold_cost * 100.0
        )

        rows.append(
            {
                "instance": enhanced[0]["instance"] if enhanced else key,
                "threshold_archive_points": len(threshold_archive),
                "mcts_archive_points": len(enhanced_archive),
                "new_archive_points": len(new_points),
                "threshold_best_feasible_cost": f"{best_threshold_cost:.3f}",
                "mcts_best_feasible_cost": f"{best_enhanced_cost:.3f}",
                "best_cost_improvement_pct": f"{cost_improvement_pct:.2f}",
                "coverage_mcts_over_threshold": f"{coverage(enhanced_archive, threshold_archive):.3f}",
                "coverage_threshold_over_mcts": f"{coverage(threshold_archive, enhanced_archive):.3f}",
                "threshold_hypervolume": f"{threshold_hv:.3f}",
                "mcts_hypervolume": f"{enhanced_hv:.3f}",
                "hypervolume_gain_pct": f"{0.0 if threshold_hv == 0.0 else (enhanced_hv - threshold_hv) / threshold_hv * 100.0:.2f}",
                "threshold_runtime_seconds": f"{threshold_runtime:.3f}",
                "mcts_runtime_seconds": f"{enhanced_runtime:.3f}",
                "threshold_feasibility_rate": f"{len(threshold_feasible) / len(threshold):.3f}" if threshold else "",
                "mcts_feasibility_rate": f"{len(enhanced_feasible) / len(enhanced):.3f}" if enhanced else "",
                "mcts_unique_evaluations": meta.get("unique_mcts_evaluations", ""),
                "mcts_iterations": meta.get("iterations", ""),
                "mcts_seed": meta.get("random_seed", ""),
                "mcts_sha256": file_sha256(mcts_path),
            }
        )

    csv_text = rows_to_csv(rows)
    if write_output:
        write_csv(output_csv, rows)
    return rows, csv_text


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--threshold-dir", type=Path, default=Path("results/pareto_ls"))
    parser.add_argument("--mcts-dir", type=Path, default=Path("results/mcts_service_mode"))
    parser.add_argument("--output-csv", type=Path, default=Path("results/tables/mcts_threshold_comparison.csv"))
    parser.add_argument("--emit-json", action="store_true")
    args = parser.parse_args()
    rows, csv_text = summarize(args.threshold_dir, args.mcts_dir, args.output_csv, write_output=not args.emit_json)
    if args.emit_json:
        print(json.dumps({"csv": csv_text, "rows": len(rows)}))
    else:
        print(f"wrote {args.output_csv} ({len(rows)} rows)")


if __name__ == "__main__":
    main()
