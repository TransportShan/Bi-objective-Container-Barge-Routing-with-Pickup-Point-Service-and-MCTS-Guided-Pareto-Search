from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable


@dataclass(frozen=True)
class SolomonNode:
    node_id: int
    x: float
    y: float
    demand: float
    ready_time: float
    due_time: float
    service_time: float


@dataclass(frozen=True)
class SolomonInstance:
    name: str
    vehicle_count: int
    vehicle_capacity: float
    depot: SolomonNode
    customers: tuple[SolomonNode, ...]
    source_file: str

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "vehicle_count": self.vehicle_count,
            "vehicle_capacity": self.vehicle_capacity,
            "depot": asdict(self.depot),
            "customers": [asdict(node) for node in self.customers],
            "source_file": self.source_file,
        }


def _numeric_rows(lines: Iterable[str]) -> list[list[float]]:
    rows: list[list[float]] = []
    for raw in lines:
        parts = raw.strip().split()
        if len(parts) < 7:
            continue
        try:
            rows.append([float(part) for part in parts[:7]])
        except ValueError:
            continue
    return rows


def parse_solomon_file(path: str | Path) -> SolomonInstance:
    file_path = Path(path)
    lines = file_path.read_text(encoding="utf-8", errors="ignore").splitlines()
    non_empty = [line.strip() for line in lines if line.strip()]
    if not non_empty:
        raise ValueError(f"Empty instance file: {file_path}")

    name = non_empty[0]
    vehicle_count = None
    capacity = None
    for idx, line in enumerate(non_empty):
        if line.upper().startswith("NUMBER") and idx + 1 < len(non_empty):
            parts = non_empty[idx + 1].split()
            if len(parts) >= 2:
                vehicle_count = int(float(parts[0]))
                capacity = float(parts[1])
                break

    if vehicle_count is None or capacity is None:
        raise ValueError(f"Could not parse vehicle count/capacity from {file_path}")

    rows = _numeric_rows(non_empty)
    if len(rows) < 2:
        raise ValueError(f"Could not parse customer rows from {file_path}")

    nodes = [
        SolomonNode(
            node_id=int(row[0]),
            x=row[1],
            y=row[2],
            demand=row[3],
            ready_time=row[4],
            due_time=row[5],
            service_time=row[6],
        )
        for row in rows
    ]
    depot = nodes[0]
    customers = tuple(nodes[1:])
    return SolomonInstance(
        name=name,
        vehicle_count=vehicle_count,
        vehicle_capacity=capacity,
        depot=depot,
        customers=customers,
        source_file=str(file_path),
    )


def find_instance_files(raw_dir: str | Path) -> list[Path]:
    root = Path(raw_dir)
    candidates = []
    for path in root.rglob("*.txt"):
        try:
            parse_solomon_file(path)
        except ValueError:
            continue
        candidates.append(path)
    return sorted(candidates)
