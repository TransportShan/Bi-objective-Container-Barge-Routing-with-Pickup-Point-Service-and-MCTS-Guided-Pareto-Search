from __future__ import annotations

import csv
import json
import math
import shutil
import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
FIGURES = RESULTS / "figures"
TABLES = RESULTS / "tables"
SUBMISSION_FIGURES = ROOT / "submission_cie_elsarticle" / "figures"

sys.path.insert(0, str(ROOT / "src"))

from constructive_solver import build_routes, make_stops, route_cost  # noqa: E402
from pareto_local_search_solver import local_search  # noqa: E402


def read_csv(path: Path) -> list[dict]:
    with path.open("r", newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def load_all_rows() -> list[dict]:
    rows: list[dict] = []
    for path in sorted((RESULTS / "pareto_ls").glob("*_pareto_ls.csv")):
        for row in read_csv(path):
            row["_path"] = str(path)
            rows.append(row)
    return rows


def load_instances() -> dict[str, dict]:
    instances: dict[str, dict] = {}
    for path in sorted(RESULTS.glob("single_*.json")):
        if path.stat().st_size == 0:
            continue
        data = json.loads(path.read_text(encoding="utf-8"))
        data["_path"] = str(path)
        instances[data["name"]] = data
    return instances


def to_float(row: dict, key: str) -> float:
    return float(row[key])


def to_int(row: dict, key: str) -> int:
    return int(float(row[key]))


def is_true(row: dict, key: str) -> bool:
    return str(row[key]).lower() == "true"


def instance_family(name: str) -> str:
    if name.startswith("RC"):
        return "RC"
    if name.startswith("R"):
        return "R"
    return "C"


def round_str(value: float, digits: int = 3) -> str:
    return f"{value:.{digits}f}"


def summarize_instances(rows: list[dict], instances: dict[str, dict]) -> list[dict]:
    output: list[dict] = []
    for instance_name in sorted({row["instance"] for row in rows}):
        inst_rows = [row for row in rows if row["instance"] == instance_name]
        feasible = [row for row in inst_rows if is_true(row, "feasible")]
        archive = [row for row in feasible if is_true(row, "archive_point")]
        inst = instances[instance_name]
        constructive_best = min((to_float(row, "initial_transport_cost") for row in feasible), default=math.nan)
        ls_best = min((to_float(row, "transport_cost") for row in feasible), default=math.nan)
        improvement_pct = 0.0 if not feasible or constructive_best == 0 else (constructive_best - ls_best) / constructive_best * 100.0
        max_row_improvement_pct = max(
            (
                to_float(row, "cost_improvement") / to_float(row, "initial_transport_cost") * 100.0
                for row in feasible
                if to_float(row, "initial_transport_cost") > 0
            ),
            default=0.0,
        )
        output.append(
            {
                "instance": instance_name,
                "family": instance_family(instance_name),
                "customers": len(inst["customers"]),
                "pickup_points": len(inst["pickup_points"]),
                "vehicles": inst["vehicle_count"],
                "capacity": round_str(float(inst["vehicle_capacity"]), 1),
                "alpha": round_str(float(inst["alpha"]), 2),
                "feasible_rows": len(feasible),
                "archive_points": len(archive),
                "constructive_best": round_str(constructive_best),
                "ls_best": round_str(ls_best),
                "best_improvement_pct": round_str(improvement_pct, 2),
                "max_row_improvement_pct": round_str(max_row_improvement_pct, 2),
                "max_indirect": max((to_int(row, "indirect_count") for row in feasible), default=0),
                "accepted_moves": sum(to_int(row, "moves_accepted") for row in inst_rows),
            }
        )
    return output


def summarize_thresholds(rows: list[dict]) -> list[dict]:
    output: list[dict] = []
    for threshold in sorted({to_float(row, "threshold") for row in rows}):
        threshold_rows = [row for row in rows if abs(to_float(row, "threshold") - threshold) < 1e-9]
        feasible = [row for row in threshold_rows if is_true(row, "feasible")]
        archive = [row for row in threshold_rows if is_true(row, "archive_point")]
        if feasible:
            avg_cost = sum(to_float(row, "transport_cost") for row in feasible) / len(feasible)
            avg_diss = sum(to_float(row, "dissatisfaction") for row in feasible) / len(feasible)
            avg_indirect = sum(to_int(row, "indirect_count") for row in feasible) / len(feasible)
            avg_routes = sum(to_int(row, "routes_used") for row in feasible) / len(feasible)
        else:
            avg_cost = avg_diss = avg_indirect = avg_routes = math.nan
        output.append(
            {
                "threshold": round_str(threshold, 1),
                "feasible_instances": len(feasible),
                "archive_points": len(archive),
                "mean_transport_cost": round_str(avg_cost),
                "mean_dissatisfaction": round_str(avg_diss),
                "mean_indirect_customers": round_str(avg_indirect, 1),
                "mean_routes": round_str(avg_routes, 1),
            }
        )
    return output


def archive_rows(rows: list[dict]) -> list[dict]:
    output: list[dict] = []
    for row in rows:
        if not is_true(row, "archive_point"):
            continue
        output.append(
            {
                "instance": row["instance"],
                "threshold": round_str(to_float(row, "threshold"), 1),
                "transport_cost": round_str(to_float(row, "transport_cost")),
                "dissatisfaction": round_str(to_float(row, "dissatisfaction")),
                "direct_count": to_int(row, "direct_count"),
                "indirect_count": to_int(row, "indirect_count"),
                "routes_used": to_int(row, "routes_used"),
                "cost_improvement": round_str(to_float(row, "cost_improvement")),
            }
        )
    return sorted(output, key=lambda r: (r["instance"], float(r["dissatisfaction"]), float(r["transport_cost"])))


def summarize_sensitivity(rows: list[dict]) -> list[dict]:
    output: list[dict] = []
    for instance_name in sorted({row["instance"] for row in rows}):
        archive = [
            row
            for row in rows
            if row["instance"] == instance_name and is_true(row, "archive_point") and is_true(row, "feasible")
        ]
        archive.sort(key=lambda row: (to_float(row, "dissatisfaction"), to_float(row, "transport_cost")))
        if len(archive) < 2:
            row = archive[0] if archive else None
            output.append(
                {
                    "instance": instance_name,
                    "from_threshold": "",
                    "to_threshold": "",
                    "cost_saving": "",
                    "dissatisfaction_increase": "",
                    "saving_per_dissat": "",
                    "relative_saving_pct": "",
                    "note": "single archive point",
                }
            )
            continue
        best_transition: dict | None = None
        for first, second in zip(archive, archive[1:]):
            cost_saving = to_float(first, "transport_cost") - to_float(second, "transport_cost")
            diss_increase = to_float(second, "dissatisfaction") - to_float(first, "dissatisfaction")
            if cost_saving <= 1e-9 or diss_increase <= 1e-9:
                continue
            rel_saving = cost_saving / to_float(first, "transport_cost") * 100.0
            candidate = {
                "instance": instance_name,
                "from_threshold": round_str(to_float(first, "threshold"), 1),
                "to_threshold": round_str(to_float(second, "threshold"), 1),
                "cost_saving": cost_saving,
                "dissatisfaction_increase": diss_increase,
                "saving_per_dissat": cost_saving / diss_increase,
                "relative_saving_pct": rel_saving,
                "note": "largest relative adjacent saving",
            }
            if best_transition is None or candidate["relative_saving_pct"] > best_transition["relative_saving_pct"]:
                best_transition = candidate
        if best_transition is None:
            output.append(
                {
                    "instance": instance_name,
                    "from_threshold": "",
                    "to_threshold": "",
                    "cost_saving": "",
                    "dissatisfaction_increase": "",
                    "saving_per_dissat": "",
                    "relative_saving_pct": "",
                    "note": "no decreasing-cost adjacent pair",
                }
            )
        else:
            output.append(
                {
                    "instance": best_transition["instance"],
                    "from_threshold": best_transition["from_threshold"],
                    "to_threshold": best_transition["to_threshold"],
                    "cost_saving": round_str(best_transition["cost_saving"]),
                    "dissatisfaction_increase": round_str(best_transition["dissatisfaction_increase"]),
                    "saving_per_dissat": round_str(best_transition["saving_per_dissat"]),
                    "relative_saving_pct": round_str(best_transition["relative_saving_pct"], 2),
                    "note": best_transition["note"],
                }
            )
    return output


def summarize_knees(rows: list[dict]) -> list[dict]:
    output: list[dict] = []
    for instance_name in sorted({row["instance"] for row in rows}):
        archive = [
            row
            for row in rows
            if row["instance"] == instance_name and is_true(row, "archive_point") and is_true(row, "feasible")
        ]
        if not archive:
            continue
        min_cost = min(to_float(row, "transport_cost") for row in archive)
        max_cost = max(to_float(row, "transport_cost") for row in archive)
        min_diss = min(to_float(row, "dissatisfaction") for row in archive)
        max_diss = max(to_float(row, "dissatisfaction") for row in archive)

        def score(row: dict) -> float:
            cost_span = max(max_cost - min_cost, 1e-9)
            diss_span = max(max_diss - min_diss, 1e-9)
            cost_norm = (to_float(row, "transport_cost") - min_cost) / cost_span
            diss_norm = (to_float(row, "dissatisfaction") - min_diss) / diss_span
            return math.hypot(cost_norm, diss_norm)

        chosen = min(archive, key=score)
        output.append(
            {
                "instance": instance_name,
                "threshold": round_str(to_float(chosen, "threshold"), 1),
                "transport_cost": round_str(to_float(chosen, "transport_cost")),
                "dissatisfaction": round_str(to_float(chosen, "dissatisfaction")),
                "indirect_count": to_int(chosen, "indirect_count"),
                "routes_used": to_int(chosen, "routes_used"),
                "selection_score": round_str(score(chosen), 3),
                "note": "closest archive point to normalized ideal",
            }
        )
    return output


def font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    candidates = [
        Path("C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf"),
        Path("C:/Windows/Fonts/calibrib.ttf" if bold else "C:/Windows/Fonts/calibri.ttf"),
    ]
    for candidate in candidates:
        if candidate.exists():
            return ImageFont.truetype(str(candidate), size=size)
    return ImageFont.load_default()


def draw_text(draw: ImageDraw.ImageDraw, xy: tuple[int, int], text: str, size: int = 18, fill=(40, 40, 40), bold: bool = False) -> None:
    draw.text(xy, text, font=font(size, bold), fill=fill)


def save_canvas(img: Image.Image, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    img.save(path)
    SUBMISSION_FIGURES.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, SUBMISSION_FIGURES / path.name)


def scale(value: float, lo: float, hi: float, out_lo: float, out_hi: float) -> float:
    if abs(hi - lo) < 1e-12:
        return (out_lo + out_hi) / 2
    return out_lo + (value - lo) / (hi - lo) * (out_hi - out_lo)


def draw_pareto_figure(rows: list[dict], path: Path) -> None:
    width, height = 1450, 1610
    img = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(img)
    draw_text(draw, (55, 35), "Cost-service archives by benchmark test set", 34, bold=True)
    draw_text(draw, (55, 80), "Gray points are feasible threshold rows; blue points are unique nondominated archive points.", 20, fill=(80, 80, 80))
    names = sorted({row["instance"] for row in rows})
    panel_w, panel_h = 620, 310
    start_x, start_y = 70, 140
    gap_x, gap_y = 70, 45
    cols = 2
    for idx, name in enumerate(names):
        col, row_idx = idx % cols, idx // cols
        x0 = start_x + col * (panel_w + gap_x)
        y0 = start_y + row_idx * (panel_h + gap_y)
        x1 = x0 + panel_w
        y1 = y0 + panel_h
        feasible = [r for r in rows if r["instance"] == name and is_true(r, "feasible")]
        archive = [r for r in feasible if is_true(r, "archive_point")]
        diss_vals = [to_float(r, "dissatisfaction") for r in feasible] or [0.0]
        cost_vals = [to_float(r, "transport_cost") for r in feasible] or [0.0]
        diss_min, diss_max = min(diss_vals), max(diss_vals)
        cost_min, cost_max = min(cost_vals), max(cost_vals)
        diss_pad = max((diss_max - diss_min) * 0.08, 0.5)
        cost_pad = max((cost_max - cost_min) * 0.08, 1.0)
        diss_min -= diss_pad
        diss_max += diss_pad
        cost_min -= cost_pad
        cost_max += cost_pad
        plot_left, plot_top = x0 + 82, y0 + 58
        plot_right, plot_bottom = x1 - 34, y1 - 66
        draw.rectangle((x0, y0, x1, y1), outline=(180, 180, 180), width=2)
        draw.rectangle((plot_left, plot_top, plot_right, plot_bottom), outline=(232, 232, 232), width=1)
        draw.line((plot_left, plot_bottom, plot_right, plot_bottom), fill=(70, 70, 70), width=2)
        draw.line((plot_left, plot_top, plot_left, plot_bottom), fill=(70, 70, 70), width=2)
        draw_text(draw, (x0 + 16, y0 + 14), name, 19, bold=True)
        draw_text(draw, (x0 + 250, y1 - 47), "dissatisfaction", 16, fill=(90, 90, 90))
        draw_text(draw, (x0 + 18, y0 + 118), "cost", 16, fill=(90, 90, 90))
        for r in feasible:
            px = scale(to_float(r, "dissatisfaction"), diss_min, diss_max, plot_left + 8, plot_right - 8)
            py = scale(to_float(r, "transport_cost"), cost_min, cost_max, plot_bottom - 8, plot_top + 8)
            draw.ellipse((px - 6, py - 6, px + 6, py + 6), outline=(135, 135, 135), width=2)
        archive_sorted = sorted(archive, key=lambda r: to_float(r, "dissatisfaction"))
        points = []
        for r in archive_sorted:
            px = scale(to_float(r, "dissatisfaction"), diss_min, diss_max, plot_left + 8, plot_right - 8)
            py = scale(to_float(r, "transport_cost"), cost_min, cost_max, plot_bottom - 8, plot_top + 8)
            points.append((px, py))
        if len(points) >= 2:
            draw.line(points, fill=(31, 100, 170), width=4)
        for r, (px, py) in zip(archive_sorted, points):
            draw.ellipse((px - 9, py - 9, px + 9, py + 9), fill=(31, 100, 170), outline=(20, 60, 100))
            draw_text(draw, (int(px + 11), int(py - 13)), f"{to_float(r, 'threshold'):g}", 15, fill=(31, 100, 170))
    save_canvas(img, path)


def draw_improvement_figure(summary: list[dict], path: Path) -> None:
    width, height = 1400, 900
    img = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(img)
    draw_text(draw, (55, 35), "Best feasible cost reduction from deterministic local search", 34, bold=True)
    draw_text(draw, (55, 80), "Reduction is measured against the best feasible constructive threshold row in the same instance.", 20, fill=(80, 80, 80))
    data = sorted(summary, key=lambda r: float(r["best_improvement_pct"]), reverse=True)
    left, top = 330, 150
    bar_h, gap = 45, 24
    max_val = max(float(r["best_improvement_pct"]) for r in data) or 1
    for idx, row in enumerate(data):
        y = top + idx * (bar_h + gap)
        label = row["instance"]
        value = float(row["best_improvement_pct"])
        draw_text(draw, (40, y + 9), label, 18)
        x_end = left + int(value / max_val * 860)
        color = (45, 126, 180) if value > 0 else (170, 170, 170)
        draw.rectangle((left, y, x_end, y + bar_h), fill=color)
        draw.rectangle((left, y, left + 860, y + bar_h), outline=(220, 220, 220))
        draw_text(draw, (x_end + 12, y + 8), f"{value:.2f}%", 18, bold=True)
    draw_text(draw, (left, height - 60), "Percent reduction in best feasible transportation cost", 20, fill=(70, 70, 70))
    save_canvas(img, path)


def draw_threshold_figure(thresholds: list[dict], path: Path) -> None:
    width, height = 1450, 900
    img = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(img)
    draw_text(draw, (55, 35), "Aggregate threshold response across feasible rows", 34, bold=True)
    draw_text(draw, (55, 80), "Bars show feasible instance count; the line shows mean indirect customers among feasible rows.", 20, fill=(80, 80, 80))
    x0, y0, x1, y1 = 120, 150, 1350, 760
    draw.rectangle((x0, y0, x1, y1), outline=(180, 180, 180), width=2)
    max_feas = max(int(r["feasible_instances"]) for r in thresholds) or 1
    max_indirect = max(float(r["mean_indirect_customers"]) for r in thresholds if r["mean_indirect_customers"] != "nan") or 1
    n = len(thresholds)
    step = (x1 - x0 - 80) / n
    bar_w = step * 0.55
    line_points = []
    for idx, row in enumerate(thresholds):
        cx = x0 + 55 + idx * step + step / 2
        feasible = int(row["feasible_instances"])
        indirect = float(row["mean_indirect_customers"])
        bar_top = scale(feasible, 0, max_feas, y1 - 65, y0 + 45)
        draw.rectangle((cx - bar_w / 2, bar_top, cx + bar_w / 2, y1 - 65), fill=(111, 160, 196))
        draw_text(draw, (int(cx - 10), int(bar_top - 26)), str(feasible), 16, fill=(40, 90, 130), bold=True)
        py = scale(indirect, 0, max_indirect, y1 - 65, y0 + 45)
        line_points.append((cx, py))
        draw_text(draw, (int(cx - 18), y1 - 48), row["threshold"], 16)
    if len(line_points) > 1:
        draw.line(line_points, fill=(196, 85, 65), width=5)
    for cx, py in line_points:
        draw.ellipse((cx - 8, py - 8, cx + 8, py + 8), fill=(196, 85, 65), outline=(130, 45, 35))
    draw_text(draw, (x0 + 470, y1 + 20), "dissatisfaction threshold", 20)
    draw_text(draw, (x0 + 15, y0 + 15), "feasible count", 18, fill=(40, 90, 130))
    draw_text(draw, (x1 - 300, y0 + 15), "mean indirect customers", 18, fill=(160, 55, 45))
    save_canvas(img, path)


def reconstruct_routes(instance: dict, threshold: float) -> tuple[list[list], list]:
    depot, stops, _ = make_stops(instance, threshold)
    routes, feasible = build_routes(stops, depot, float(instance["vehicle_capacity"]), int(instance["vehicle_count"]))
    if feasible:
        routes, _ = local_search(routes, depot, float(instance["vehicle_capacity"]), int(instance["vehicle_count"]), max_passes=100)
    return routes, [depot, *stops]


def draw_route_figure(instances: dict[str, dict], path: Path) -> None:
    instance = instances["C102_n50_p10_a0p25"]
    thresholds = [0.0, 1.0]
    panels = []
    for threshold in thresholds:
        routes, stops = reconstruct_routes(instance, threshold)
        panels.append((threshold, routes, stops))

    width, height = 1650, 900
    img = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(img)
    draw_text(draw, (55, 35), "Service-mode route sketches for C102_n50_p10_a0p25", 34, bold=True)
    draw_text(draw, (55, 80), "Solid arrows are barge routes; dashed gray lines connect indirect customers to pickup points.", 20, fill=(80, 80, 80))

    all_x = [float(instance["depot"]["x"])] + [float(c["x"]) for c in instance["customers"]] + [float(p["x"]) for p in instance["pickup_points"]]
    all_y = [float(instance["depot"]["y"])] + [float(c["y"]) for c in instance["customers"]] + [float(p["y"]) for p in instance["pickup_points"]]
    min_x = max(0.0, math.floor((min(all_x) - 5) / 10) * 10)
    max_x = math.ceil((max(all_x) + 5) / 10) * 10
    min_y = max(0.0, math.floor((min(all_y) - 5) / 10) * 10)
    max_y = math.ceil((max(all_y) + 5) / 10) * 10
    customers = {int(row["node_id"]): row for row in instance["customers"]}

    def draw_dashed_line(p1: tuple[float, float], p2: tuple[float, float], fill: tuple[int, int, int], width_px: int = 2, dash: int = 9, gap: int = 7) -> None:
        x1, y1 = p1
        x2, y2 = p2
        length = math.hypot(x2 - x1, y2 - y1)
        if length < 1e-9:
            return
        ux, uy = (x2 - x1) / length, (y2 - y1) / length
        pos = 0.0
        while pos < length:
            end = min(pos + dash, length)
            draw.line((x1 + ux * pos, y1 + uy * pos, x1 + ux * end, y1 + uy * end), fill=fill, width=width_px)
            pos += dash + gap

    def draw_arrow_segment(p1: tuple[float, float], p2: tuple[float, float], fill: tuple[int, int, int], width_px: int = 3) -> None:
        x1, y1 = p1
        x2, y2 = p2
        length = math.hypot(x2 - x1, y2 - y1)
        if length < 1e-9:
            return
        draw.line((x1, y1, x2, y2), fill=fill, width=width_px)
        angle = math.atan2(y2 - y1, x2 - x1)
        tip_x = x1 + 0.62 * (x2 - x1)
        tip_y = y1 + 0.62 * (y2 - y1)
        size = 13
        left = (tip_x - size * math.cos(angle - math.pi / 6), tip_y - size * math.sin(angle - math.pi / 6))
        right = (tip_x - size * math.cos(angle + math.pi / 6), tip_y - size * math.sin(angle + math.pi / 6))
        draw.polygon(((tip_x, tip_y), left, right), fill=fill)

    for panel_idx, (threshold, routes, stops) in enumerate(panels):
        x0 = 70 + panel_idx * 790
        y0 = 150
        x1 = x0 + 720
        y1 = 790
        plot_left, plot_top = x0 + 72, y0 + 105
        plot_right, plot_bottom = x1 - 35, y1 - 62
        draw.rectangle((x0, y0, x1, y1), outline=(180, 180, 180), width=2)
        draw_text(draw, (x0 + 20, y0 + 18), f"threshold = {threshold:g}", 24, bold=True)
        direct = sum(1 for s in stops if getattr(s, "kind", "") == "direct_customer")
        pickup = sum(1 for s in stops if getattr(s, "kind", "") == "pickup_point")
        indirect = sum(len(getattr(s, "members", ())) for s in stops if getattr(s, "kind", "") == "pickup_point")
        draw_text(draw, (x0 + 20, y0 + 52), f"direct {direct}, indirect {indirect}, pickup stops {pickup}, routes {len(routes)}", 18, fill=(75, 75, 75))
        draw.rectangle((plot_left, plot_top, plot_right, plot_bottom), outline=(55, 55, 55), width=2)
        for tick in range(int(min_x), int(max_x) + 1, 10):
            tx = scale(tick, min_x, max_x, plot_left, plot_right)
            draw.line((tx, plot_bottom, tx, plot_bottom + 8), fill=(70, 70, 70), width=1)
            draw.line((tx, plot_top, tx, plot_top - 5), fill=(160, 160, 160), width=1)
            draw_text(draw, (int(tx - 9), plot_bottom + 12), str(tick), 13, fill=(80, 80, 80))
        for tick in range(int(min_y), int(max_y) + 1, 10):
            ty = scale(tick, min_y, max_y, plot_bottom, plot_top)
            draw.line((plot_left - 8, ty, plot_left, ty), fill=(70, 70, 70), width=1)
            draw.line((plot_right, ty, plot_right + 5, ty), fill=(160, 160, 160), width=1)
            draw_text(draw, (plot_left - 38, int(ty - 8)), str(tick), 13, fill=(80, 80, 80))

        def px(x: float) -> float:
            return scale(x, min_x, max_x, plot_left, plot_right)

        def py(y: float) -> float:
            return scale(y, min_y, max_y, plot_bottom, plot_top)

        depot = stops[0]
        indirect_customer_ids = set()
        for stop in stops[1:]:
            if stop.kind == "pickup_point":
                for customer_id in stop.members:
                    indirect_customer_ids.add(customer_id)
                    customer = customers[customer_id]
                    draw_dashed_line(
                        (px(float(customer["x"])), py(float(customer["y"]))),
                        (px(stop.x), py(stop.y)),
                        fill=(155, 155, 155),
                        width_px=2,
                    )
        for route in routes:
            seq = [depot, *route, depot]
            coords = [(px(s.x), py(s.y)) for s in seq]
            for a, b in zip(coords, coords[1:]):
                draw_arrow_segment(a, b, fill=(35, 35, 35), width_px=3)
        for customer_id in sorted(indirect_customer_ids):
            customer = customers[customer_id]
            x, y = px(float(customer["x"])), py(float(customer["y"]))
            draw.ellipse((x - 4, y - 4, x + 4, y + 4), fill="white", outline=(115, 115, 115), width=2)
        for stop in stops[1:]:
            x, y = px(stop.x), py(stop.y)
            if stop.kind == "direct_customer":
                draw.ellipse((x - 5, y - 5, x + 5, y + 5), fill=(40, 95, 170))
            else:
                draw.rectangle((x - 8, y - 8, x + 8, y + 8), fill=(225, 170, 45), outline=(130, 85, 20), width=2)
        dx, dy = px(depot.x), py(depot.y)
        draw.regular_polygon((dx, dy, 12), n_sides=5, rotation=-90, fill=(30, 30, 30))
    legend_y = 840
    draw.regular_polygon((82, legend_y + 9, 10), n_sides=5, rotation=-90, fill=(30, 30, 30))
    draw_text(draw, (105, legend_y), "hub/depot", 18, fill=(75, 75, 75))
    draw.rectangle((245, legend_y, 263, legend_y + 18), fill=(225, 170, 45), outline=(130, 85, 20))
    draw_text(draw, (275, legend_y), "pickup point", 18, fill=(75, 75, 75))
    draw.ellipse((455, legend_y + 1, 471, legend_y + 17), fill=(40, 95, 170))
    draw_text(draw, (485, legend_y), "direct customer", 18, fill=(75, 75, 75))
    draw.ellipse((705, legend_y + 1, 721, legend_y + 17), fill="white", outline=(115, 115, 115), width=2)
    draw_text(draw, (735, legend_y), "indirect customer", 18, fill=(75, 75, 75))
    draw_arrow_segment((970, legend_y + 9), (1030, legend_y + 9), fill=(35, 35, 35), width_px=3)
    draw_text(draw, (1048, legend_y), "barge route", 18, fill=(75, 75, 75))
    draw_dashed_line((1260, legend_y + 9), (1320, legend_y + 9), fill=(155, 155, 155), width_px=2)
    draw_text(draw, (1338, legend_y), "pickup access", 18, fill=(75, 75, 75))
    save_canvas(img, path)


def main() -> None:
    FIGURES.mkdir(parents=True, exist_ok=True)
    TABLES.mkdir(parents=True, exist_ok=True)
    rows = load_all_rows()
    instances = load_instances()
    instance_summary = summarize_instances(rows, instances)
    threshold_summary = summarize_thresholds(rows)
    archive = archive_rows(rows)
    sensitivity = summarize_sensitivity(rows)
    knees = summarize_knees(rows)

    write_csv(TABLES / "analysis_instance_summary.csv", instance_summary)
    write_csv(TABLES / "analysis_threshold_summary.csv", threshold_summary)
    write_csv(TABLES / "analysis_archive_points.csv", archive)
    write_csv(TABLES / "analysis_sensitivity_transitions.csv", sensitivity)
    write_csv(TABLES / "analysis_managerial_knee_points.csv", knees)

    draw_pareto_figure(rows, FIGURES / "fig_pareto_archives.png")
    draw_improvement_figure(instance_summary, FIGURES / "fig_best_cost_improvement.png")
    draw_threshold_figure(threshold_summary, FIGURES / "fig_threshold_response.png")
    draw_route_figure(instances, FIGURES / "fig_route_threshold_comparison.png")

    print(TABLES / "analysis_instance_summary.csv")
    print(TABLES / "analysis_threshold_summary.csv")
    print(TABLES / "analysis_archive_points.csv")
    print(TABLES / "analysis_sensitivity_transitions.csv")
    print(TABLES / "analysis_managerial_knee_points.csv")
    print(FIGURES / "fig_pareto_archives.png")
    print(FIGURES / "fig_best_cost_improvement.png")
    print(FIGURES / "fig_threshold_response.png")
    print(FIGURES / "fig_route_threshold_comparison.png")


if __name__ == "__main__":
    main()
