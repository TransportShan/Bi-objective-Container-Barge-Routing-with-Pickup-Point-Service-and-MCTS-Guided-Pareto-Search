from __future__ import annotations

import argparse
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path

from solomon_io import SolomonNode, parse_solomon_file


@dataclass(frozen=True)
class PickupPoint:
    pickup_id: int
    x: float
    y: float
    source_customer_id: int


def euclidean(a: SolomonNode | PickupPoint, b: SolomonNode | PickupPoint) -> float:
    return math.hypot(a.x - b.x, a.y - b.y)


def farthest_first_pickups(customers: list[SolomonNode], pickup_count: int) -> list[PickupPoint]:
    if pickup_count <= 0:
        raise ValueError("pickup_count must be positive")
    if pickup_count > len(customers):
        raise ValueError("pickup_count cannot exceed number of customers")

    center_x = sum(node.x for node in customers) / len(customers)
    center_y = sum(node.y for node in customers) / len(customers)
    first = min(customers, key=lambda n: (math.hypot(n.x - center_x, n.y - center_y), n.node_id))
    selected = [first]
    remaining = {node.node_id: node for node in customers if node.node_id != first.node_id}

    while len(selected) < pickup_count:
        next_node = max(
            remaining.values(),
            key=lambda node: (
                min(euclidean(node, chosen) for chosen in selected),
                -node.node_id,
            ),
        )
        selected.append(next_node)
        del remaining[next_node.node_id]

    return [
        PickupPoint(
            pickup_id=10_000 + idx,
            x=node.x,
            y=node.y,
            source_customer_id=node.node_id,
        )
        for idx, node in enumerate(selected, start=1)
    ]


def dissatisfaction(distance: float, alpha: float) -> float:
    if alpha <= 0:
        raise ValueError("alpha must be positive")
    ratio = min(max(distance / alpha, 0.0), 1.0)
    return 10.0 * (ratio**4)


def derive_instance(
    source_path: str | Path,
    output_dir: str | Path,
    customer_count: int,
    pickup_ratio: float,
    alpha_ratio: float,
) -> Path:
    derived = build_derived_instance(source_path, customer_count, pickup_ratio, alpha_ratio)
    out_dir = Path(output_dir)
    out_path = out_dir / f"{derived['name']}.json"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(derived, indent=2), encoding="utf-8")
    return out_path


def build_derived_instance(
    source_path: str | Path,
    customer_count: int,
    pickup_ratio: float,
    alpha_ratio: float,
) -> dict:
    source = parse_solomon_file(source_path)
    customers = list(source.customers[:customer_count])
    if len(customers) < customer_count:
        raise ValueError(f"{source_path} has only {len(customers)} customers")

    pickup_count = max(2, math.ceil(customer_count * pickup_ratio))
    pickups = farthest_first_pickups(customers, pickup_count)
    spread = max(
        math.hypot(a.x - b.x, a.y - b.y)
        for i, a in enumerate(customers)
        for b in customers[i + 1 :]
    )
    alpha = alpha_ratio * spread

    nearest = {}
    for customer in customers:
        pickup = min(pickups, key=lambda p: (euclidean(customer, p), p.pickup_id))
        distance = euclidean(customer, pickup)
        nearest[str(customer.node_id)] = {
            "pickup_id": pickup.pickup_id,
            "distance": distance,
            "eligible": distance <= alpha,
            "dissatisfaction": dissatisfaction(distance, alpha),
        }

    alpha_token = f"{alpha_ratio:g}".replace(".", "p")
    return {
        "schema": "barge_pickup_v1",
        "name": f"{source.name}_n{customer_count}_p{pickup_count}_a{alpha_token}",
        "source": {
            "benchmark": "SINTEF TOP VRPTW via ML4VRP2023",
            "source_file": str(Path(source_path)),
            "original_instance": source.name,
            "note": (
                "This is a benchmark-derived instance. Pickup points are deterministic "
                "medoids selected from Solomon/Homberger customer coordinates; it is not "
                "field-observed maritime data."
            ),
        },
        "vehicle_count": source.vehicle_count,
        "vehicle_capacity": source.vehicle_capacity,
        "depot": asdict(source.depot),
        "customers": [asdict(node) for node in customers],
        "pickup_points": [asdict(point) for point in pickups],
        "alpha": alpha,
        "alpha_ratio": alpha_ratio,
        "nearest_pickup": nearest,
        "distance_metric": "Euclidean distance; travel time equals distance, following VRPTW benchmark convention.",
        "service_policy": (
            "Each customer may be served directly at its customer node or indirectly through "
            "its nearest eligible pickup point. Indirect service adds dissatisfaction according "
            "to 10*(distance/alpha)^4."
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("--output-dir", type=Path, default=Path("data/derived"))
    parser.add_argument("--customers", type=int, default=50)
    parser.add_argument("--pickup-ratio", type=float, default=0.2)
    parser.add_argument("--alpha-ratio", type=float, default=0.25)
    parser.add_argument("--stdout", action="store_true")
    args = parser.parse_args()
    if args.stdout:
        derived = build_derived_instance(
            args.source,
            args.customers,
            args.pickup_ratio,
            args.alpha_ratio,
        )
        print(json.dumps(derived, indent=2))
        return
    out_path = derive_instance(
        args.source,
        args.output_dir,
        args.customers,
        args.pickup_ratio,
        args.alpha_ratio,
    )
    print(out_path)


if __name__ == "__main__":
    main()
