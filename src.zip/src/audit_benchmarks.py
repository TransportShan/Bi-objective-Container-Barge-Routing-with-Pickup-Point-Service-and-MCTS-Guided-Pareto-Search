from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from file_utils import atomic_write_text
from solomon_io import find_instance_files, parse_solomon_file


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def build_manifest(raw_root: Path, output_path: Path) -> None:
    entries = []
    for path in find_instance_files(raw_root):
        instance = parse_solomon_file(path)
        entries.append(
            {
                "name": instance.name,
                "relative_path": str(path.relative_to(raw_root)),
                "sha256": sha256(path),
                "customer_count": len(instance.customers),
                "vehicle_count": instance.vehicle_count,
                "vehicle_capacity": instance.vehicle_capacity,
                "source_family": "ML4VRP2023/Solomon-Homberger VRPTW",
                "source_url": "https://github.com/ML4VRP/ML4VRP2023",
                "source_note": (
                    "The ML4VRP2023 repository packages Solomon 100-customer and "
                    "Gehring-Homberger larger VRPTW instances. Derived barge-pickup "
                    "instances must cite the benchmark source and the deterministic "
                    "conversion script."
                ),
            }
        )

    atomic_write_text(output_path, json.dumps(entries, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw-root", type=Path, default=Path("data/raw/ml4vrp2023"))
    parser.add_argument("--output", type=Path, default=Path("data/raw/ml4vrp2023/manifest_parseable.json"))
    args = parser.parse_args()
    build_manifest(args.raw_root, args.output)
    print(args.output)


if __name__ == "__main__":
    main()
